﻿# NX 1872
# Journal created by ASUS on Sat May 11 17:45:19 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject1 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject1
    feature1 = sketch1.Feature
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId4)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    scaleAboutPoint1 = NXOpen.Point3d(18.441458333333301, 8.9495312499999997, 0.0)
    viewCenter1 = NXOpen.Point3d(-18.441458333333301, -8.9495312499999997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(23.051822916666627, 11.186914062499998, 0.0)
    viewCenter2 = NXOpen.Point3d(-23.051822916666627, -11.186914062499998, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(35.170979817708314, 18.644856770833336, 0.0)
    viewCenter3 = NXOpen.Point3d(-35.170979817708314, -18.644856770833336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(28.814778645833311, 14.91588541666667, 0.0)
    viewCenter4 = NXOpen.Point3d(-28.814778645833311, -14.91588541666667, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(23.051822916666648, 11.932708333333336, 0.0)
    viewCenter5 = NXOpen.Point3d(-23.051822916666648, -11.932708333333336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(20.61104166666664, 12.366624999999999, 0.0)
    viewCenter6 = NXOpen.Point3d(-20.61104166666664, -12.366624999999999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(9.0254666666666559, -6.9426666666666561, 0.0)
    viewCenter7 = NXOpen.Point3d(-9.0254666666666559, 6.9426666666666561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(7.3765833333333211, -12.80054166666666, 0.0)
    viewCenter8 = NXOpen.Point3d(-7.3765833333333211, 12.80054166666666, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(5.1527604166666503, -18.983854166666649, 0.0)
    viewCenter9 = NXOpen.Point3d(-5.1527604166666503, 18.983854166666649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    origin4 = NXOpen.Point3d(39.328443880208361, 0.0, -15.646085807291135)
    workPart.ModelingViews.WorkView.SetOrigin(origin4)
    
    origin5 = NXOpen.Point3d(39.328443880208361, 0.0, -15.646085807291135)
    workPart.ModelingViews.WorkView.SetOrigin(origin5)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId6, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(81.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(81.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(81.0, 0.0, 16.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(81.0, 0.0, 16.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 16.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 16.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(40.5, 0.0, -11.531249999999996)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(92.53125, 0.0, 8.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId7, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    parallelDimension1 = dimension1
    point3 = NXOpen.Point3d(41.362428255208364, 0.0, -15.382865791268754)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(parallelDimension1, workPart.ModelingViews.WorkView, point3)
    
    point1_1 = NXOpen.Point3d(81.0, 0.0, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    sketchRapidDimensionBuilder1.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder1 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList1 = convertToFromReferenceBuilder1.InputObjects
    
    added1 = selectNXObjectList1.Add(parallelDimension1)
    
    convertToFromReferenceBuilder1.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject2 = convertToFromReferenceBuilder1.Commit()
    
    convertToFromReferenceBuilder1.Destroy()
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("120")
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(1.4814814814814814)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId8, None)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId7, "Edit Driving Value")
    
    parallelDimension2 = dimension2
    point4 = NXOpen.Point3d(135.38286579126876, 0.0, 8.7617266927088586)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(parallelDimension2, workPart.ModelingViews.WorkView, point4)
    
    point1_3 = NXOpen.Point3d(120.0, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    sketchRapidDimensionBuilder1.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder2 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList2 = convertToFromReferenceBuilder2.InputObjects
    
    added2 = selectNXObjectList2.Add(parallelDimension2)
    
    convertToFromReferenceBuilder2.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject3 = convertToFromReferenceBuilder2.Commit()
    
    convertToFromReferenceBuilder2.Destroy()
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId9, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId10, None)
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId9, "Edit Driving Value")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.68472633830681928
    rotMatrix1.Xy = 0.72861126227027384
    rotMatrix1.Xz = -0.016597292606135294
    rotMatrix1.Yx = -0.48041190178396043
    rotMatrix1.Yy = 0.46836736009814456
    rotMatrix1.Yz = 0.74150955531200891
    rotMatrix1.Zx = 0.54804584320406424
    rotMatrix1.Zy = -0.49975758572293105
    rotMatrix1.Zz = 0.67073698963090833
    translation1 = NXOpen.Point3d(-13.137740960084457, 55.364196725090082, -45.001740970278391)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.78048780487804903)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    theSession.UndoToMark(markId11, None)
    
    theSession.DeleteUndoMark(markId11, None)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId13, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(63.460327796686613, -7.1054273576010019e-15, 0.0)
    section1.AddToSection(rules1, line1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId15, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId14, None)
    
    extrudeBuilder1.Limits.SymmetricOption = True
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder1.Limits.EndExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("120")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("120")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("60")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId16, None)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId17, None)
    
    theSession.SetUndoMarkName(markId13, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.65843863265865599
    rotMatrix2.Xy = 0.75260129238295659
    rotMatrix2.Xz = 0.0070612836016733863
    rotMatrix2.Yx = -0.48632927522510316
    rotMatrix2.Yy = 0.41828376699161213
    rotMatrix2.Yz = 0.76715221848752579
    rotMatrix2.Zx = 0.57440613078345981
    rotMatrix2.Zy = -0.50855676671814154
    rotMatrix2.Zz = 0.64142623265934828
    translation2 = NXOpen.Point3d(-1.6684808586699305, 12.50765808240056, 7.3379826988635415)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.97560975609756106)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.64156782442156279
    rotMatrix3.Xy = 0.76578295050609091
    rotMatrix3.Xz = -0.044353121436600126
    rotMatrix3.Yx = -0.43930477845094118
    rotMatrix3.Yy = 0.41421603226060166
    rotMatrix3.Yz = 0.79714264109283106
    rotMatrix3.Zx = 0.62881001765012667
    rotMatrix3.Zy = -0.49193653181327318
    rotMatrix3.Zz = 0.60215978807155235
    translation3 = NXOpen.Point3d(-0.39916033925297256, 9.5362361629243146, 4.2700817098025112)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.97560975609756106)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects1 = [NXOpen.DisplayableObject.Null] * 5 
    objects1[0] = sketch2
    objects1[1] = line1
    objects1[2] = line2
    objects1[3] = line3
    objects1[4] = line4
    theSession.DisplayManager.BlankObjects(objects1)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.71901692999652012
    rotMatrix4.Xy = 0.69404556798781802
    rotMatrix4.Xz = 0.036268497830038417
    rotMatrix4.Yx = -0.38148107342677789
    rotMatrix4.Yy = 0.35050906194937143
    rotMatrix4.Yz = 0.85534530343512483
    rotMatrix4.Zx = 0.58093617979562351
    rotMatrix4.Zy = -0.62884349964664543
    rotMatrix4.Zz = 0.51678719794188799
    translation4 = NXOpen.Point3d(-5.4492147700836, 5.7758005497630478, 7.5693749317210219)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.97560975609756106)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin6, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId19, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 150 * 160 {(0,-60,10)(0,0,10)(0,60,10) EXTRUDE(2)}")
    point5 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 120 * 160 {(0,60,10)(60,60,10)(120,60,10) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 160 {(60,0,10) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin7, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin8, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point6 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    # ----------------------------------------------
    #   Menu: OK
    # ----------------------------------------------
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId20, None)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject4 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject4
    feature3 = sketch3.Feature
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId22)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId21, None)
    
    theSession.SetUndoMarkName(markId19, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point6)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression12)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    origin9 = NXOpen.Point3d(103.32640624999993, -20.40510416666665, 10.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin9)
    
    origin10 = NXOpen.Point3d(103.32640624999993, -20.40510416666665, 10.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId24, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(0.0, 54.987916666666678, 9.9999999999999858)
    endPoint5 = NXOpen.Point3d(115.8015104166666, 54.987916666666678, 9.9999999999999858)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(115.8015104166666, 54.987916666666678, 9.9999999999999858)
    endPoint6 = NXOpen.Point3d(115.8015104166666, -59.999999999999858, 9.9999999999999858)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(115.8015104166666, -59.999999999999858, 9.9999999999999858)
    endPoint7 = NXOpen.Point3d(0.0, -59.999999999999858, 9.9999999999999858)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(0.0, -59.999999999999858, 9.9999999999999858)
    endPoint8 = NXOpen.Point3d(0.0, 54.987916666666678, 9.9999999999999858)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line5
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom6)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line7
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    edge3 = extrude1.FindObject("EDGE * 130 * 160 {(0,-60,10)(60,-60,10)(120,-60,10) EXTRUDE(2)}")
    conGeom2_9.Geometry = edge3
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 115.8015104166666
    help1.Point.Y = -60.0
    help1.Point.Z = 9.9999999999999858
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_9, conGeom2_9, help1)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = line5
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line5
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(57.900755208333301, 45.762916666666676, 9.9999999999999858)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint3
    dimension3 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression16 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line6
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line6
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(106.57651041666659, -2.5060416666665901, 9.9999999999999858)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression17 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId26, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    parallelDimension3 = dimension3
    theSession.UpdateManager.LogForUpdate(parallelDimension3)
    
    startPoint9 = NXOpen.Point3d(10.034322916666611, 53.903125000000017, 9.9999999999999858)
    endPoint9 = NXOpen.Point3d(115.8015104166666, 53.903125000000017, 9.9999999999999858)
    line5.SetEndpoints(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(115.8015104166666, -59.999999999999858, 9.9999999999999858)
    endPoint10 = NXOpen.Point3d(10.034322916666632, -59.999999999999858, 9.9999999999999858)
    line7.SetEndpoints(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(10.034322916666632, -59.999999999999858, 9.9999999999999858)
    endPoint11 = NXOpen.Point3d(10.034322916666611, 53.903125000000017, 9.9999999999999858)
    line8.SetEndpoints(startPoint11, endPoint11)
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId26)
    
    geoms5 = [NXOpen.SmartObject.Null] * 3 
    geoms5[0] = line5
    geoms5[1] = line7
    geoms5[2] = line8
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 3 
    geoms6[0] = line5
    geoms6[1] = line7
    geoms6[2] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms6)
    
    geoms7 = [NXOpen.SmartObject.Null] * 3 
    geoms7[0] = line5
    geoms7[1] = line7
    geoms7[2] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms7)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId28, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension3)
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension1)
    
    parallelDimension4 = dimension4
    theSession.UpdateManager.LogForUpdate(parallelDimension4)
    
    startPoint12 = NXOpen.Point3d(10.034322916666611, 53.903125000000017, 9.9999999999999858)
    endPoint12 = NXOpen.Point3d(115.53031249999994, 53.903125000000017, 9.9999999999999858)
    line5.SetEndpoints(startPoint12, endPoint12)
    
    startPoint13 = NXOpen.Point3d(115.53031249999995, -60.0, 9.9999999999999858)
    endPoint13 = NXOpen.Point3d(10.034322916666632, -59.999999999999858, 9.9999999999999858)
    line7.SetEndpoints(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(115.53031249999994, 53.903125000000017, 9.9999999999999858)
    endPoint14 = NXOpen.Point3d(115.53031249999995, -60.0, 9.9999999999999858)
    line6.SetEndpoints(startPoint14, endPoint14)
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("ENTITY 243 1 1")
    sketchHelpedDimensionalConstraint5.Refresh()
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId28)
    
    geoms8 = [NXOpen.SmartObject.Null] * 3 
    geoms8[0] = line5
    geoms8[1] = line7
    geoms8[2] = line6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms8)
    
    geoms9 = [NXOpen.SmartObject.Null] * 3 
    geoms9[0] = line5
    geoms9[1] = line7
    geoms9[2] = line6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 3 
    geoms10[0] = line5
    geoms10[1] = line7
    geoms10[2] = line6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId30, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension3)
    
    theSession.UpdateManager.LogForUpdate(perpendicularDimension1)
    
    theSession.UpdateManager.LogForUpdate(parallelDimension4)
    
    startPoint15 = NXOpen.Point3d(10.034322916666611, 53.903125000000017, 9.9999999999999858)
    endPoint15 = NXOpen.Point3d(116.88630208333338, 53.903125000000017, 9.9999999999999858)
    line5.SetEndpoints(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(116.88630208333325, -60.0, 9.9999999999999858)
    endPoint16 = NXOpen.Point3d(10.034322916666632, -59.999999999999858, 9.9999999999999858)
    line7.SetEndpoints(startPoint16, endPoint16)
    
    startPoint17 = NXOpen.Point3d(116.88630208333338, 53.903125000000017, 9.9999999999999858)
    endPoint17 = NXOpen.Point3d(116.88630208333325, -60.0, 9.9999999999999858)
    line6.SetEndpoints(startPoint17, endPoint17)
    
    sketchHelpedDimensionalConstraint5.Refresh()
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId30)
    
    geoms11 = [NXOpen.SmartObject.Null] * 3 
    geoms11[0] = line5
    geoms11[1] = line7
    geoms11[2] = line6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 3 
    geoms12[0] = line5
    geoms12[1] = line7
    geoms12[2] = line6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms12)
    
    geoms13 = [NXOpen.SmartObject.Null] * 3 
    geoms13[0] = line5
    geoms13[1] = line7
    geoms13[2] = line6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms13)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId32, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint18 = NXOpen.Point3d(8.0, 49.0, 9.9999999999999858)
    endPoint18 = NXOpen.Point3d(112.0, 49.0, 9.9999999999999858)
    line9 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(112.0, 49.0, 9.9999999999999858)
    endPoint19 = NXOpen.Point3d(112.0, -52.0, 9.9999999999999858)
    line10 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(112.0, -52.0, 9.9999999999999858)
    endPoint20 = NXOpen.Point3d(8.0, -52.0, 9.9999999999999858)
    line11 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    startPoint21 = NXOpen.Point3d(8.0, -52.0, 9.9999999999999858)
    endPoint21 = NXOpen.Point3d(8.0, 49.0, 9.9999999999999858)
    line12 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom7.Geometry = line9
    geom7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom7)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line9
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line10
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line10
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line11
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line11
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line12
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line12
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line9
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line9
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line9
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(60.0, 39.774999999999999, 9.9999999999999858)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression18 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line10
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line10
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(102.77500000000001, -1.5, 9.9999999999999858)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression19 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms14 = [NXOpen.SmartObject.Null] * 4 
    geoms14[0] = line9
    geoms14[1] = line10
    geoms14[2] = line11
    geoms14[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms14)
    
    geoms15 = [NXOpen.SmartObject.Null] * 4 
    geoms15[0] = line9
    geoms15[1] = line10
    geoms15[2] = line11
    geoms15[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms15)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines9 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines12)
    
    theSession.SetUndoMarkName(markId33, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    point7 = NXOpen.Point3d(112.0, 41.428020833333349, 9.9999999999999858)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line10, workPart.ModelingViews.WorkView, point7)
    
    point1_5 = NXOpen.Point3d(112.0, 49.0, 9.9999999999999858)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(112.0, -52.0, 9.9999999999999858)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    edge4 = extrude1.FindObject("EDGE * 160 * 170 {(120,-60,10)(120,0,10)(120,60,10) EXTRUDE(2)}")
    point1_7 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(112.0, 41.428020833333349, 9.9999999999999858)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(112.0, 41.428020833333349, 9.9999999999999858)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point8 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point8
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point9 = NXOpen.Point3d(117.69989583333324, 36.546458333333355, 9.9999999999999858)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point9)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject5 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId33, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId33, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId35, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p4")
    expression20.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId35, "Edit Driving Value")
    
    point10 = NXOpen.Point3d(93.563281249999946, 49.000000000000036, 9.9999999999999858)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point10)
    
    point1_12 = NXOpen.Point3d(118.49999999999997, 49.000000000000028, 9.9999999999999858)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(14.499999999999972, 49.000000000000028, 9.9999999999999858)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    point1_14 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(93.563281249999946, 49.000000000000036, 9.9999999999999858)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(93.563281249999946, 49.000000000000036, 9.9999999999999858)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(120.0, 60.0, 10.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point11 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point11
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point12 = NXOpen.Point3d(92.478489583333271, 54.174322916666689, 9.9999999999999858)
    sketchRapidDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.TextCentered = True
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    expression21 = workPart.Expressions.FindObject("p5")
    expression21.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId39, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId40, None)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId39, "Edit Driving Value")
    
    point13 = NXOpen.Point3d(14.5, 37.088854166666707, 9.9999999999999858)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(line12, workPart.ModelingViews.WorkView, point13)
    
    point1_19 = NXOpen.Point3d(14.5, 58.5, 9.9999999999999858)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line12, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(14.500000000000018, -42.500000000000043, 9.9999999999999858)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_21 = NXOpen.Point3d(1.133932221432744e-16, 60.0, 9.9999999999999858)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge1, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(14.5, 37.088854166666707, 9.9999999999999858)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(1.133932221432744e-16, 60.0, 9.9999999999999858)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge1, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(14.5, 37.088854166666707, 9.9999999999999858)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(1.133932221432744e-16, 60.0, 9.9999999999999858)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge1, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point14 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point14
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point15 = NXOpen.Point3d(8.1359374999999545, 34.105677083333354, 9.9999999999999858)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point15)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = True
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId42, None)
    
    theSession.SetUndoMarkName(markId41, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId41, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId43, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression22 = workPart.Expressions.FindObject("p6")
    expression22.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId44, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId43, "Edit Driving Value")
    
    point16 = NXOpen.Point3d(76.206614583333277, -42.500000000000014, 9.9999999999999858)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(line11, workPart.ModelingViews.WorkView, point16)
    
    point1_26 = NXOpen.Point3d(118.50000000000006, -42.5, 9.9999999999999858)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(1.5000000000000142, -42.500000000000043, 9.9999999999999858)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    point1_28 = NXOpen.Point3d(60.0, -60.0, 9.9999999999999929)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge3, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(76.206614583333277, -42.500000000000014, 9.9999999999999858)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(60.0, -60.0, 9.9999999999999929)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge3, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(76.206614583333277, -42.500000000000014, 9.9999999999999858)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(60.0, -60.0, 9.9999999999999929)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge3, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point17 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point17
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point18 = NXOpen.Point3d(77.020208333333272, -51.592864583333309, 9.9999999999999858)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point18)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = True
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject8 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId46, None)
    
    theSession.SetUndoMarkName(markId45, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId45, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId47, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression23 = workPart.Expressions.FindObject("p7")
    expression23.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId48, None)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId47, "Edit Driving Value")
    
    sketchRapidDimensionBuilder6.Destroy()
    
    theSession.UndoToMark(markId49, None)
    
    theSession.DeleteUndoMark(markId49, None)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch4 = theSession.ActiveSketch
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("60")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("60")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId51, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(32.20046234023917, -58.500000000000121, 10.000000000000039)
    section2.AddToSection(rules2, line11, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId53, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction4
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId52, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies14)
    
    targetBodies15 = []
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies15)
    
    direction5 = extrudeBuilder2.Direction
    
    success1 = direction5.ReverseDirection()
    
    extrudeBuilder2.Direction = direction5
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("7")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies24)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.75449904400378898
    rotMatrix5.Xy = 0.65267549382823531
    rotMatrix5.Xz = 0.068890437314905795
    rotMatrix5.Yx = -0.39664153279585901
    rotMatrix5.Yy = 0.36984021873551981
    rotMatrix5.Yz = 0.84017480744605488
    rotMatrix5.Zx = 0.52288305294656545
    rotMatrix5.Zy = -0.66123589766567747
    rotMatrix5.Zz = 0.53792229976042738
    translation5 = NXOpen.Point3d(-7.3848123472672995, 6.5959615629070214, 11.151255432786471)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.97560975609756095)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId54, None)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkName(markId51, "Extrude")
    
    expression26 = extrudeBuilder2.Limits.StartExtend.Value
    expression27 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression24)
    
    workPart.Expressions.Delete(expression25)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects2 = [NXOpen.DisplayableObject.Null] * 5 
    objects2[0] = line9
    objects2[1] = line10
    objects2[2] = line11
    objects2[3] = line12
    objects2[4] = sketch4
    theSession.DisplayManager.BlankObjects(objects2)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.91137415865645022
    rotMatrix6.Xy = 0.38682114798322609
    rotMatrix6.Xz = 0.1405935361465345
    rotMatrix6.Yx = -0.24621453196222795
    rotMatrix6.Yy = 0.23867478620292601
    rotMatrix6.Yz = 0.93936827212846119
    rotMatrix6.Zx = 0.32981138122246301
    rotMatrix6.Zy = -0.89073214037887405
    rotMatrix6.Zz = 0.31276302037198195
    translation6 = NXOpen.Point3d(-17.155834720585112, -2.9256258105228756, 23.86135213317484)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 0.97560975609756095)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin11, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId57, "Create Sketch Dialog")
    
    direction6 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction6, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin12, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = datumPlane1
    plane8.SetGeometry(geom8)
    
    plane8.SetFlip(True)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin13, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = datumPlane1
    plane9.SetGeometry(geom9)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject9 = sketchInPlaceBuilder3.Commit()
    
    sketch5 = nXObject9
    feature5 = sketch5.Feature
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId60)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkName(markId57, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression31)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    origin14 = NXOpen.Point3d(65.629895833333322, 0.0, -34.170937499999987)
    workPart.ModelingViews.WorkView.SetOrigin(origin14)
    
    origin15 = NXOpen.Point3d(65.629895833333322, 0.0, -34.170937499999987)
    workPart.ModelingViews.WorkView.SetOrigin(origin15)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId62, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint22 = NXOpen.Point3d(14.102291666666659, 0.0, 0.0)
    endPoint22 = NXOpen.Point3d(26.102291666666659, 0.0, 0.0)
    line13 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(26.102291666666659, 0.0, 0.0)
    endPoint23 = NXOpen.Point3d(26.102291666666659, 0.0, -12.0)
    line14 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(26.102291666666659, 0.0, -12.0)
    endPoint24 = NXOpen.Point3d(14.102291666666659, 0.0, -12.0)
    line15 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    startPoint25 = NXOpen.Point3d(14.102291666666659, 0.0, -12.0)
    endPoint25 = NXOpen.Point3d(14.102291666666659, 0.0, 0.0)
    line16 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line13
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line14
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line14
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line15
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line15
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line16
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line16
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line13
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom10.Geometry = line13
    geom10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateHorizontalConstraint(geom10)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line13
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line14
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line14
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line15
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line15
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line16
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line16
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line13
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line13
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    edge5 = extrude1.FindObject("EDGE * 130 * 140 {(120,-60,0)(60,-60,0)(0,-60,0) EXTRUDE(2)}")
    conGeom2_18.Geometry = edge5
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 14.102291666666659
    help2.Point.Y = 0.0
    help2.Point.Z = 0.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_18, conGeom2_18, help2)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line13
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line13
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(20.102291666666659, 0.0, -9.2250000000000014)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression32 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line14
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line14
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(16.877291666666657, 0.0, -6.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression33 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms16 = [NXOpen.SmartObject.Null] * 4 
    geoms16[0] = line13
    geoms16[1] = line14
    geoms16[2] = line15
    geoms16[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms16)
    
    geoms17 = [NXOpen.SmartObject.Null] * 4 
    geoms17[0] = line13
    geoms17[1] = line14
    geoms17[2] = line15
    geoms17[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms17)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId63, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint26 = NXOpen.Point3d(86.240937499999973, 0.0, 0.0)
    endPoint26 = NXOpen.Point3d(98.240937499999973, 0.0, 0.0)
    line17 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(98.240937499999973, 0.0, 0.0)
    endPoint27 = NXOpen.Point3d(98.240937499999973, 0.0, -18.0)
    line18 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    startPoint28 = NXOpen.Point3d(98.240937499999973, 0.0, -18.0)
    endPoint28 = NXOpen.Point3d(86.240937499999973, 0.0, -18.0)
    line19 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    startPoint29 = NXOpen.Point3d(86.240937499999973, 0.0, -18.0)
    endPoint29 = NXOpen.Point3d(86.240937499999973, 0.0, 0.0)
    line20 = workPart.Curves.CreateLine(startPoint29, endPoint29)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line17
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line18
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line18
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line19
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line19
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line20
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line20
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line17
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom11.Geometry = line17
    geom11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateHorizontalConstraint(geom11)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line17
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line18
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line18
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line19
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line19
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line20
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line20
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = line17
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_22, conGeom2_22)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line17
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = edge5
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 86.240937499999973
    help3.Point.Y = 0.0
    help3.Point.Z = 0.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_23, conGeom2_23, help3)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line17
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line17
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(92.240937499999973, 0.0, -9.2250000000000014)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression34 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line18
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line18
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(89.015937499999978, 0.0, -9.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression35 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms18 = [NXOpen.SmartObject.Null] * 4 
    geoms18[0] = line17
    geoms18[1] = line18
    geoms18[2] = line19
    geoms18[3] = line20
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms18)
    
    geoms19 = [NXOpen.SmartObject.Null] * 4 
    geoms19[0] = line17
    geoms19[1] = line18
    geoms19[2] = line19
    geoms19[3] = line20
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms19)
    
    origin16 = NXOpen.Point3d(104.41119791666668, 0.0, -33.357343749999984)
    workPart.ModelingViews.WorkView.SetOrigin(origin16)
    
    origin17 = NXOpen.Point3d(104.41119791666668, 0.0, -33.357343749999984)
    workPart.ModelingViews.WorkView.SetOrigin(origin17)
    
    scaleAboutPoint10 = NXOpen.Point3d(0.54239583333330244, 22.509427083333335, 0.0)
    viewCenter10 = NXOpen.Point3d(-0.54239583333330244, -22.509427083333335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(2.3729817708333139, 31.86575520833334, 0.0)
    viewCenter11 = NXOpen.Point3d(-2.3729817708333139, -31.86575520833334, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(5.5087076822916776, 54.663330078124993, 0.0)
    viewCenter12 = NXOpen.Point3d(-5.5087076822916776, -54.663330078124993, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(4.4069661458333131, 43.730664062499997, 0.0)
    viewCenter13 = NXOpen.Point3d(-4.4069661458333131, -43.730664062499997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(3.525572916666651, 35.255729166666669, 0.0)
    viewCenter14 = NXOpen.Point3d(-3.525572916666651, -35.255729166666669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(2.820458333333284, 28.204583333333339, 0.0)
    viewCenter15 = NXOpen.Point3d(-2.8204583333333577, -28.204583333333339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(2.2563666666666276, 22.563666666666673, 0.0)
    viewCenter16 = NXOpen.Point3d(-2.2563666666666866, -22.563666666666673, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(2.9159199999999768, 8.0534933333333374, 0.0)
    viewCenter17 = NXOpen.Point3d(-2.9159200000000238, -8.0534933333333374, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(2.5549013333333015, 6.3317119999999996, 0.0)
    viewCenter18 = NXOpen.Point3d(-2.5549013333333397, -6.3317119999999996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(2.132787199999985, 4.9765034666666681, 0.0)
    viewCenter19 = NXOpen.Point3d(-2.1327872000000152, -4.9765034666666681, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-14.360767146666683, 9.3131707733333364, 0.0)
    viewCenter20 = NXOpen.Point3d(14.360767146666658, -9.3131707733333364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-19.994880000000023, 14.396313599999996, 0.0)
    viewCenter21 = NXOpen.Point3d(19.994879999999977, -14.396313599999996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines33 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines36)
    
    theSession.SetUndoMarkName(markId64, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    point19 = NXOpen.Point3d(98.240937499999973, 0.0, -5.9019446614583471)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(line18, workPart.ModelingViews.WorkView, point19)
    
    point1_33 = NXOpen.Point3d(98.240937499999973, 0.0, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line18, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(98.240937499999973, 0.0, -18.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line18, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    edge6 = extrude1.FindObject("EDGE * 130 * 170 {(120,-60,10)(120,-60,5)(120,-60,0) EXTRUDE(2)}")
    point1_35 = NXOpen.Point3d(120.0, -60.0, 5.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(98.240937499999973, 0.0, -5.9019446614583471)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(120.0, -60.0, 5.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(98.240937499999973, 0.0, -5.9019446614583471)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    point1_39 = NXOpen.Point3d(120.0, -60.0, 5.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point20 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point20
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder7.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point21 = NXOpen.Point3d(112.16363335791664, 0.0, -11.456077994791679)
    sketchRapidDimensionBuilder7.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point21)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.TextCentered = False
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject10 = sketchRapidDimensionBuilder7.Commit()
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.SetUndoMarkName(markId64, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId64, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId66, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension2 = nXObject10
    point22 = NXOpen.Point3d(113.38554269124997, 0.0, -10.823740532308731)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(perpendicularDimension2, workPart.ModelingViews.WorkView, point22)
    
    point1_40 = NXOpen.Point3d(98.240937499999973, 0.0, -5.9019446614583471)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, NXOpen.View.Null, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    point1_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression36 = workPart.Expressions.FindObject("p10")
    expression36.SetFormula("57")
    
    theSession.SetUndoMarkVisibility(markId66, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId67, None)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId66, "Edit Driving Value")
    
    origin18 = NXOpen.Point3d(69.730054691250203, 0.0, -12.344739328125014)
    workPart.ModelingViews.WorkView.SetOrigin(origin18)
    
    origin19 = NXOpen.Point3d(69.730054691250203, 0.0, -12.344739328125014)
    workPart.ModelingViews.WorkView.SetOrigin(origin19)
    
    parallelDimension5 = dimension10
    point23 = NXOpen.Point3d(55.037097462482947, 0.0, -9.7898379947916716)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(parallelDimension5, workPart.ModelingViews.WorkView, point23)
    
    point1_42 = NXOpen.Point3d(63.0, 0.0, -18.0)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line18, NXOpen.View.Null, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder3 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList3 = convertToFromReferenceBuilder3.InputObjects
    
    added3 = selectNXObjectList3.Add(parallelDimension5)
    
    convertToFromReferenceBuilder3.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject11 = convertToFromReferenceBuilder3.Commit()
    
    convertToFromReferenceBuilder3.Destroy()
    
    expression37 = workPart.Expressions.FindObject("p11")
    expression37.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId68, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId69, None)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId68, "Edit Driving Value")
    
    parallelDimension6 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point24 = NXOpen.Point3d(59.288284024583547, 0.0, -5.0406574624829457)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(parallelDimension6, workPart.ModelingViews.WorkView, point24)
    
    point1_44 = NXOpen.Point3d(62.999999999999993, 0.0, 0.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line17, NXOpen.View.Null, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder4 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList4 = convertToFromReferenceBuilder4.InputObjects
    
    added4 = selectNXObjectList4.Add(parallelDimension6)
    
    convertToFromReferenceBuilder4.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject12 = convertToFromReferenceBuilder4.Commit()
    
    convertToFromReferenceBuilder4.Destroy()
    
    expression38 = workPart.Expressions.FindObject("p12")
    expression38.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId71, None)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId70, "Edit Driving Value")
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    point25 = NXOpen.Point3d(8.6345880245835502, 0.0, 2.516462537517052)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(perpendicularDimension3, workPart.ModelingViews.WorkView, point25)
    
    line21 = theSession.ActiveSketch.FindObject("Curve DATUM10")
    point1_46 = NXOpen.Point3d(0.0, 0.0, 14.287499999999998)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line21, NXOpen.View.Null, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder5 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList5 = convertToFromReferenceBuilder5.InputObjects
    
    added5 = selectNXObjectList5.Add(perpendicularDimension3)
    
    convertToFromReferenceBuilder5.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject13 = convertToFromReferenceBuilder5.Commit()
    
    convertToFromReferenceBuilder5.Destroy()
    
    expression39 = workPart.Expressions.FindObject("p13")
    expression39.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId72, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId73, None)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId72, "Edit Driving Value")
    
    parallelDimension7 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    point26 = NXOpen.Point3d(11.300572024583552, 0.0, -5.0406574624829457)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(parallelDimension7, workPart.ModelingViews.WorkView, point26)
    
    point1_48 = NXOpen.Point3d(16.0, 0.0, 0.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, NXOpen.View.Null, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder6 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList6 = convertToFromReferenceBuilder6.InputObjects
    
    added6 = selectNXObjectList6.Add(parallelDimension7)
    
    convertToFromReferenceBuilder6.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject14 = convertToFromReferenceBuilder6.Commit()
    
    convertToFromReferenceBuilder6.Destroy()
    
    expression40 = workPart.Expressions.FindObject("p14")
    expression40.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId74, "Edit Driving Value")
    
    parallelDimension8 = dimension8
    point27 = NXOpen.Point3d(2.4139586912502295, 0.0, -6.9016886614583424)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(parallelDimension8, workPart.ModelingViews.WorkView, point27)
    
    point1_50 = NXOpen.Point3d(12.000000000000007, 0.0, -12.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, NXOpen.View.Null, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    point1_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    sketchRapidDimensionBuilder8.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder7 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList7 = convertToFromReferenceBuilder7.InputObjects
    
    added7 = selectNXObjectList7.Add(parallelDimension8)
    
    convertToFromReferenceBuilder7.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject15 = convertToFromReferenceBuilder7.Commit()
    
    convertToFromReferenceBuilder7.Destroy()
    
    expression41 = workPart.Expressions.FindObject("p15")
    expression41.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId77, None)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId76, "Edit Driving Value")
    
    sketchRapidDimensionBuilder8.Destroy()
    
    theSession.UndoToMark(markId78, None)
    
    theSession.DeleteUndoMark(markId78, None)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch6 = theSession.ActiveSketch
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.7869395256409073
    rotMatrix7.Xy = 0.59110666008771839
    rotMatrix7.Xz = 0.17697202994825684
    rotMatrix7.Yx = -0.069091053074821843
    rotMatrix7.Yy = -0.20059456173986445
    rotMatrix7.Yz = 0.97723500151468523
    rotMatrix7.Zx = 0.61314974465384564
    rotMatrix7.Zy = -0.7812520324455724
    rotMatrix7.Zz = -0.11701560763671282
    translation7 = NXOpen.Point3d(-9.6897567396525375, -13.553034543767243, 6.8610503272918848)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 0.97560975609756095)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId80, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature5
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(12.000000000000005, -5.3290705182007514e-15, -6.5420786033157814)
    section3.AddToSection(rules3, line14, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId82, None)
    
    direction7 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction7
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies28)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId81, None)
    
    extrudeBuilder3.Limits.SymmetricOption = True
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("4")
    
    extrudeBuilder3.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder3.Limits.EndExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies29)
    
    scaleAboutPoint22 = NXOpen.Point3d(95.461666666666645, -31.730156249999997, 0.0)
    viewCenter22 = NXOpen.Point3d(-95.461666666666645, 31.730156249999997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(82.715364583333297, -38.645703124999997, 0.0)
    viewCenter23 = NXOpen.Point3d(-82.715364583333297, 38.645703124999997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(108.9029134114583, -37.713460286458314, 0.0)
    viewCenter24 = NXOpen.Point3d(-108.9029134114583, 37.713460286458314, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(87.461328124999994, -30.509765624999996, 0.0)
    viewCenter25 = NXOpen.Point3d(-87.461328124999994, 30.509765624999996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(69.969062500000035, -24.679010416666625, 0.0)
    viewCenter26 = NXOpen.Point3d(-69.969062499999993, 24.67901041666665, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(55.975250000000038, -19.743208333333303, 0.0)
    viewCenter27 = NXOpen.Point3d(-55.97524999999996, 19.743208333333339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(19.439466666666689, -36.275433333333304, 0.0)
    viewCenter28 = NXOpen.Point3d(-19.439466666666629, 36.275433333333361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(16.245840000000026, -28.048373333333291, 0.0)
    viewCenter29 = NXOpen.Point3d(-16.245839999999976, 28.048373333333352, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(13.441002666666689, -21.772202666666622, 0.0)
    viewCenter30 = NXOpen.Point3d(-13.441002666666632, 21.772202666666697, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.22529638621753958
    rotMatrix8.Xy = 0.95244321188672254
    rotMatrix8.Xz = 0.20516692347506615
    rotMatrix8.Yx = -0.045205091195198568
    rotMatrix8.Yy = -0.20013521739466142
    rotMatrix8.Yz = 0.97872488191954587
    rotMatrix8.Zx = 0.97324099692077903
    rotMatrix8.Zy = -0.22977776848359124
    rotMatrix8.Zz = -0.0020344589822916658
    translation8 = NXOpen.Point3d(-6.8127429180077534, 7.2207157808132845, -13.721212521958392)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 2.9773246951219519)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.15157494848701547
    rotMatrix9.Xy = 0.9653348315613528
    rotMatrix9.Xz = 0.21249399512827838
    rotMatrix9.Yx = -0.18597375721913259
    rotMatrix9.Yy = -0.18328687747257091
    rotMatrix9.Yz = 0.96530807630111426
    rotMatrix9.Zx = 0.97079287008968063
    rotMatrix9.Zy = -0.18583482859995176
    rotMatrix9.Zz = 0.15174524658871241
    translation9 = NXOpen.Point3d(-2.5220334157796529, 15.345398830543623, -13.196192254166519)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 2.9773246951219519)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.34432854537928653
    rotMatrix10.Xy = 0.91325539677074541
    rotMatrix10.Xz = 0.21772099831228081
    rotMatrix10.Yx = 0.058124886102521867
    rotMatrix10.Yy = -0.25219363718031657
    rotMatrix10.Yz = 0.96592953520499425
    rotMatrix10.Zx = 0.93704821138111938
    rotMatrix10.Zy = -0.31994210356699726
    rotMatrix10.Zz = -0.13992033416402253
    translation10 = NXOpen.Point3d(-13.679857369020638, 1.2004480168003027, -11.967236932334941)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.9773246951219519)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("10")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder3.Destroy()
    
    section3.Destroy()
    
    workPart.Expressions.Delete(expression42)
    
    workPart.Expressions.Delete(expression43)
    
    workPart.Expressions.Delete(expression44)
    
    theSession.UndoToMark(markId80, None)
    
    theSession.DeleteUndoMark(markId80, None)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Enter Direct Sketch")
    
    theSession.SetUndoMarkVisibility(markId83, "Enter Direct Sketch", NXOpen.Session.MarkVisibility.Visible)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension9 = nXObject12
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension9)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId84, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits251 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits253 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits257 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId85, None)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point28 = workPart.Points.FindObject("ENTITY 2 8")
    assocOrigin6.PointOnGeometry = point28
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point29 = NXOpen.Point3d(59.926870722996419, 0.0, -4.3109256595166592)
    sketchLinearDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point29)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits269 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits275 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId86, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId86, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId84, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject16 = sketchLinearDimensionBuilder1.Commit()
    
    point1_52 = NXOpen.Point3d(57.000000000000007, 0.0, 0.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line17, NXOpen.View.Null, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    point1_53 = NXOpen.Point3d(62.999999999999993, 0.0, 0.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line17, NXOpen.View.Null, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("6")
    
    theSession.SetUndoMarkName(markId87, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId84, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject17 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.SetUndoMarkName(markId84, "Linear Dimension")
    
    expression45 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.SetUndoMarkVisibility(markId84, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId87, None)
    
    theSession.DeleteUndoMark(markId86, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension10 = nXObject14
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension10)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId90, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits281 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits283 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits287 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId91, None)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("6")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject18 = sketchLinearDimensionBuilder2.Commit()
    
    point1_54 = NXOpen.Point3d(4.0, 0.0, 0.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line13, NXOpen.View.Null, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(10.0, 0.0, 0.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, NXOpen.View.Null, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    theSession.SetUndoMarkName(markId92, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId92, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject19 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId94, None)
    
    theSession.SetUndoMarkName(markId90, "Linear Dimension")
    
    expression46 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId93, None)
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId92, None)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch7 = theSession.ActiveSketch
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId96, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    features4[0] = sketchFeature3
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section4.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint4 = NXOpen.Point3d(10.000000000000016, -8.8817841970012523e-16, -3.778923060639471)
    section4.AddToSection(rules4, line14, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId98, None)
    
    direction8 = workPart.Directions.CreateDirection(sketch7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction8
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies33)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies34)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId97, None)
    
    extrudeBuilder4.Limits.SymmetricOption = True
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("4")
    
    extrudeBuilder4.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder4.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder4.Limits.EndExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("10")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies36)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.2973533588205044
    rotMatrix11.Xy = 0.92004586389734866
    rotMatrix11.Xz = 0.25514033064874253
    rotMatrix11.Yx = -0.03018306049299279
    rotMatrix11.Yy = -0.25803576719709304
    rotMatrix11.Yz = 0.96566377466812359
    rotMatrix11.Zx = 0.9542902927607736
    rotMatrix11.Zy = -0.2948442829230265
    rotMatrix11.Zz = -0.048958002105539536
    translation11 = NXOpen.Point3d(-10.925150706451834, 6.3490331819108903, -12.933939355640021)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 2.977324695121951)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies37)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.49623689269543614
    rotMatrix12.Xy = 0.86818129847686332
    rotMatrix12.Xz = -0.0031905019998276244
    rotMatrix12.Yx = -0.15149944924034708
    rotMatrix12.Yy = 0.090211721601468828
    rotMatrix12.Yz = 0.98433214016691306
    rotMatrix12.Zx = 0.85486657626079554
    rotMatrix12.Zy = -0.4879785633209035
    rotMatrix12.Zz = 0.17629537297223266
    translation12 = NXOpen.Point3d(-22.630397970149545, 13.430169515430521, -7.0416160934446665)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 2.977324695121951)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId99, None)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId100, None)
    
    theSession.SetUndoMarkName(markId96, "Extrude")
    
    expression50 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression47)
    
    workPart.Expressions.Delete(expression48)
    
    workPart.Expressions.Delete(expression49)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.47582202353121011
    rotMatrix13.Xy = 0.87952418593460813
    rotMatrix13.Xz = -0.0055324749195068169
    rotMatrix13.Yx = -0.015949938038909407
    rotMatrix13.Yy = 0.014917710552365467
    rotMatrix13.Yz = 0.99976150225363059
    rotMatrix13.Zx = 0.87939695325787048
    rotMatrix13.Zy = -0.47562029841875708
    rotMatrix13.Zz = 0.021126531490859007
    translation13 = NXOpen.Point3d(-21.405505820295986, 5.2971988433442583, -8.51343871326916)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 2.977324695121951)
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects3 = [NXOpen.DisplayableObject.Null] * 9 
    objects3[0] = line17
    objects3[1] = line18
    objects3[2] = line19
    objects3[3] = line20
    objects3[4] = line13
    objects3[5] = line14
    objects3[6] = line15
    objects3[7] = line16
    objects3[8] = sketch7
    theSession.DisplayManager.BlankObjects(objects3)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.98189952620728893
    rotMatrix14.Xy = -0.18849906648956108
    rotMatrix14.Xz = 0.018477617986971475
    rotMatrix14.Yx = -0.015949938038909407
    rotMatrix14.Yy = 0.014917710552365467
    rotMatrix14.Yz = 0.99976150225363059
    rotMatrix14.Zx = -0.1887297536438356
    rotMatrix14.Zy = -0.98196006224512378
    rotMatrix14.Zz = 0.011641144492565054
    translation14 = NXOpen.Point3d(-51.770155980860714, 5.2971988433442583, 55.574163700833225)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 2.977324695121951)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin20, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane10
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId102, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge7 = extrude1.FindObject("EDGE * 140 EXTRUDE(6) 150 {(4,-5,0)(7,-5,0)(10,-5,0) EXTRUDE(2)}")
    point30 = workPart.Points.CreatePoint(edge7, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction9 = workPart.Directions.CreateDirection(edge7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature6
    face2 = extrude2.FindObject("FACE 150 {(7,-5,-5) EXTRUDE(2)}")
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction9, point30, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin21, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face2
    plane11.SetGeometry(geom12)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin22, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    scalar4 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point31 = workPart.Points.CreatePoint(edge7, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face2
    plane12.SetGeometry(geom13)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId103, None)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject20 = sketchInPlaceBuilder4.Commit()
    
    sketch8 = nXObject20
    feature7 = sketch8.Feature
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId105)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.SetUndoMarkName(markId102, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression52)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point31)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression54)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression53)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    origin23 = NXOpen.Point3d(37.058201599998846, -5.0000000000000009, -6.2206293333338651)
    workPart.ModelingViews.WorkView.SetOrigin(origin23)
    
    origin24 = NXOpen.Point3d(37.058201599998846, -5.0000000000000009, -6.2206293333338651)
    workPart.ModelingViews.WorkView.SetOrigin(origin24)
    
    scaleAboutPoint31 = NXOpen.Point3d(-9.153211733333297, 1.3329920000000377, 0.0)
    viewCenter31 = NXOpen.Point3d(9.1532117333333716, -1.332991999999962, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-17.439978666666619, 1.2219093333333773, 0.0)
    viewCenter32 = NXOpen.Point3d(17.439978666666704, -1.2219093333333015, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-39.295493333333283, 4.7210133333333717, 0.0)
    viewCenter33 = NXOpen.Point3d(39.295493333333376, -4.7210133333333006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-29.214741333333276, 3.5546453333333723, 0.0)
    viewCenter34 = NXOpen.Point3d(29.214741333333389, -3.5546453333332964, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-22.127667199999944, 2.4882517333333731, 0.0)
    viewCenter35 = NXOpen.Point3d(22.127667200000051, -2.4882517333332976, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-16.493554346666606, 1.6351368533333674, 0.0)
    viewCenter36 = NXOpen.Point3d(16.493554346666727, -1.6351368533333008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId107, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(7.0000000000000036, -5.0, -5.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 2.0761286735109992, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = arc1
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(7.0000000000000036, -5.0, -4.35512576)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension11 = sketchDimensionalConstraint11.AssociatedDimension
    
    expression55 = sketchDimensionalConstraint11.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines45 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines48)
    
    theSession.SetUndoMarkName(markId108, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    point1_56 = NXOpen.Point3d(8.9273985238109113, -5.0, -5.7716509569656953)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc1, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(8.9273985238109113, -5.0, -5.7716509569656953)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point32 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point32
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point33 = NXOpen.Point3d(14.545299711998846, -5.0, -7.3370101333338589)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point33)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId109, None)
    
    theSession.SetUndoMarkName(markId108, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId108, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId110, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression56 = workPart.Expressions.FindObject("p18")
    expression56.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId110, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.72249857108520643)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId111, None)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId110, "Edit Driving Value")
    
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId112, None)
    
    theSession.DeleteUndoMark(markId112, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines57 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines60)
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension4 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    point34 = NXOpen.Point3d(5.274784682665512, -5.0, -6.1933094762173004)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(perpendicularDimension4, workPart.ModelingViews.WorkView, point34)
    
    line22 = theSession.ActiveSketch.FindObject("Curve DATUM12")
    point1_59 = NXOpen.Point3d(4.0000000000000036, -5.0, 14.287499999999998)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, NXOpen.View.Null, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    point1_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    sketchRapidDimensionBuilder11.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder8 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList8 = convertToFromReferenceBuilder8.InputObjects
    
    added8 = selectNXObjectList8.Add(perpendicularDimension4)
    
    convertToFromReferenceBuilder8.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject22 = convertToFromReferenceBuilder8.Commit()
    
    convertToFromReferenceBuilder8.Destroy()
    
    expression57 = workPart.Expressions.FindObject("p19")
    expression57.SetFormula("3")
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId113, "Edit Driving Value")
    
    point1_61 = NXOpen.Point3d(7.0000000000000036, -5.0, -3.6124928554260336)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(7.0000000000000036, -5.0, -3.6124928554260336)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    edge8 = extrude2.FindObject("EDGE * 150 * 210 {(10,-5,-10)(7,-5,-10)(4,-5,-10) EXTRUDE(2)}")
    point35 = NXOpen.Point3d(7.8341293226655129, -5.0, -10.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(edge8, workPart.ModelingViews.WorkView, point35)
    
    point1_64 = NXOpen.Point3d(7.8341293226655129, -5.0, -10.0)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge8, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(7.0000000000000036, -5.0, -3.6124928554260336)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    point1_66 = NXOpen.Point3d(7.8341293226655129, -5.0, -10.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge8, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(7.0000000000000036, -5.0, -3.6124928554260336)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point36 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point36
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point37 = NXOpen.Point3d(12.099703722665513, -5.0, -9.5551088213338602)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point37)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject23 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId116, None)
    
    theSession.SetUndoMarkName(markId115, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression58 = workPart.Expressions.FindObject("p20")
    expression58.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId117, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId118, None)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId117, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    sketchRapidDimensionBuilder12.Destroy()
    
    theSession.UndoToMark(markId119, None)
    
    theSession.DeleteUndoMark(markId119, None)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId121, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(60.5, -5.0, -5.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.1932910153979324, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = arc2
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(60.5, -5.0, -4.35512576)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_12, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension12 = sketchDimensionalConstraint12.AssociatedDimension
    
    expression59 = sketchDimensionalConstraint12.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    theSession.SetUndoMarkName(markId122, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point1_68 = NXOpen.Point3d(60.5, -5.0, -5.0)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(60.5, -5.0, -5.0)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    edge9 = extrude2.FindObject("EDGE * 130 * 190 {(63,-5,-10)(60,-5,-10)(57,-5,-10) EXTRUDE(2)}")
    point1_71 = NXOpen.Point3d(60.000000000000007, -5.0, -10.000000000000002)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge9, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(60.5, -5.0, -5.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    point1_73 = NXOpen.Point3d(60.000000000000007, -5.0, -10.000000000000002)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge9, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(60.5, -5.0, -5.0)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(60.000000000000007, -5.0, -10.000000000000002)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge9, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point38 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point38
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point39 = NXOpen.Point3d(53.561086890665507, -5.0, -8.3607479893338592)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point39)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject24 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId123, None)
    
    theSession.SetUndoMarkName(markId122, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId122, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId124, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression60 = workPart.Expressions.FindObject("p21")
    expression60.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId124, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId125, None)
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId124, "Edit Driving Value")
    
    point1_76 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    point1_77 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    point1_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point40 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point40
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point41 = NXOpen.Point3d(49.409261141332181, -5.0, -4.095173589333859)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point41)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject25 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId127, None)
    
    theSession.SetUndoMarkName(markId126, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId126, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId128, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression61 = workPart.Expressions.FindObject("p22")
    expression61.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId128, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId129, None)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId128, "Edit Driving Value")
    
    origin25 = NXOpen.Point3d(40.934986666664706, -5.0, -4.3795452160005279)
    workPart.ModelingViews.WorkView.SetOrigin(origin25)
    
    origin26 = NXOpen.Point3d(40.934986666664706, -5.0, -4.3795452160005279)
    workPart.ModelingViews.WorkView.SetOrigin(origin26)
    
    point1_79 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    edge10 = extrude2.FindObject("EDGE * 130 * 180 {(63,-5,0)(63,-5,-5)(63,-5,-10) EXTRUDE(2)}")
    point42 = NXOpen.Point3d(63.0, -5.0, -6.5407695786671933)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(edge10, workPart.ModelingViews.WorkView, point42)
    
    point1_82 = NXOpen.Point3d(63.0, -5.0, -6.5407695786671933)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge10, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    point1_83 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    point1_84 = NXOpen.Point3d(63.0, -5.0, -6.5407695786671933)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge10, workPart.ModelingViews.WorkView, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(60.5, -5.0, -6.0000000000000018)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point43 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point43
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point44 = NXOpen.Point3d(61.864738389331364, -5.0, -3.0714357333338587)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point44)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = True
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject26 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId131, None)
    
    theSession.SetUndoMarkName(markId130, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId130, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId132, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    expression62 = workPart.Expressions.FindObject("p23")
    expression62.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId132, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId133, None)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId132, "Edit Driving Value")
    
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId134, None)
    
    theSession.DeleteUndoMark(markId134, None)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch9 = theSession.ActiveSketch
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("5")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("5")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId136, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature7
    features5[0] = sketchFeature4
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section5.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint5 = NXOpen.Point3d(6.3361422834476677, -5.0, -7.3394291376443723)
    section5.AddToSection(rules5, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId138, None)
    
    direction10 = workPart.Directions.CreateDirection(sketch9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction10
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies41)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId137, None)
    
    origin27 = NXOpen.Point3d(54.947598985540765, 45.974874327665773, -5.018958789066577)
    workPart.ModelingViews.WorkView.SetOrigin(origin27)
    
    origin28 = NXOpen.Point3d(54.947598985540765, 45.974874327665773, -5.018958789066577)
    workPart.ModelingViews.WorkView.SetOrigin(origin28)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.64365819150046344
    rotMatrix15.Xy = -0.76486362211264214
    rotMatrix15.Xz = 0.026225409111983546
    rotMatrix15.Yx = -0.010748791434751867
    rotMatrix15.Yy = 0.025229331817298833
    rotMatrix15.Yz = 0.99962390142430579
    rotMatrix15.Zx = -0.76523760754229286
    rotMatrix15.Zy = -0.64369800402423916
    rotMatrix15.Zz = 0.0080177065401704061
    translation15 = NXOpen.Point3d(-24.880497774092539, 4.8959249771997184, 90.155709729801913)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 2.977324695121951)
    
    direction11 = extrudeBuilder5.Direction
    
    success2 = direction11.ReverseDirection()
    
    extrudeBuilder5.Direction = direction11
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies45)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies50)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("28")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies51)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId139, None)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.SetUndoMarkName(markId136, "Extrude")
    
    expression66 = extrudeBuilder5.Limits.StartExtend.Value
    expression67 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression63)
    
    workPart.Expressions.Delete(expression64)
    
    workPart.Expressions.Delete(expression65)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.60674318639424729
    rotMatrix16.Xy = 0.79479375031176902
    rotMatrix16.Xz = -0.012868575271426015
    rotMatrix16.Yx = -0.057006842467492498
    rotMatrix16.Yy = 0.059654729347468932
    rotMatrix16.Yz = 0.99658995237678982
    rotMatrix16.Zx = 0.7928511371474789
    rotMatrix16.Zy = -0.60394056639030491
    rotMatrix16.Zz = 0.081503782685940399
    translation16 = NXOpen.Point3d(-22.665597467719572, 7.6714080391641568, -3.3296149515843894)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 2.977324695121951)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects4 = [NXOpen.DisplayableObject.Null] * 3 
    objects4[0] = arc2
    objects4[1] = sketch9
    objects4[2] = arc1
    theSession.DisplayManager.BlankObjects(objects4)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.78320795690892675
    rotMatrix17.Xy = 0.62175945644756536
    rotMatrix17.Xz = -0.00068887776853601614
    rotMatrix17.Yx = -0.04366288994276573
    rotMatrix17.Yy = 0.056105712794837614
    rotMatrix17.Yz = 0.99746964917917891
    rotMatrix17.Zx = 0.62022483687482111
    rotMatrix17.Zy = -0.781196087618096
    rotMatrix17.Zz = 0.071090255406707992
    translation17 = NXOpen.Point3d(-33.253483698600341, 6.8707708876805516, 7.0279630647750722)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 2.977324695121951)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.30106233382060943
    rotMatrix18.Xy = 0.95283018419791554
    rotMatrix18.Xz = -0.038420193074249223
    rotMatrix18.Yx = -0.033422215193038292
    rotMatrix18.Yy = 0.050807845910228591
    rotMatrix18.Yz = 0.99814904614769728
    rotMatrix18.Zx = 0.95301858674743922
    rotMatrix18.Zy = -0.29922099337335584
    rotMatrix18.Zz = 0.047142024124816481
    translation18 = NXOpen.Point3d(-4.3247463133013007, 6.2563304026969053, -12.939661927582009)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 2.977324695121951)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin29, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane13
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId142, "Create Sketch Dialog")
    
    scalar5 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point45 = workPart.Points.CreatePoint(edge10, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge11 = extrude1.FindObject("EDGE * 140 EXTRUDE(6) 180 {(63,-5,0)(63,0,0)(63,5,0) EXTRUDE(2)}")
    direction12 = workPart.Directions.CreateDirection(edge11, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude2.FindObject("FACE 180 {(63,0,-5) EXTRUDE(2)}")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction12, point45, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin30, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom14 = [NXOpen.NXObject.Null] * 1 
    geom14[0] = face3
    plane14.SetGeometry(geom14)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin31, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression71 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar6 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point46 = workPart.Points.CreatePoint(edge10, scalar6, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face3
    plane15.SetGeometry(geom15)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    extrude3 = feature8
    face4 = extrude3.FindObject("FACE 160 {(60,0,-4.5) EXTRUDE(2)}")
    line23 = workPart.Lines.CreateFaceAxis(face4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    line23.SetVisibility(NXOpen.SmartObject.VisibilityOption.Visible)
    
    # ----------------------------------------------
    #   Menu: OK
    # ----------------------------------------------
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    objects5 = [NXOpen.TaggedObject.Null] * 1 
    objects5[0] = line23
    nErrs8 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    theSession.DeleteUndoMark(markId143, None)
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject27 = sketchInPlaceBuilder5.Commit()
    
    sketch10 = nXObject27
    feature9 = sketch10.Feature
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId145)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId144, None)
    
    theSession.SetUndoMarkName(markId142, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression69)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point46)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression68)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression71)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression70)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId147, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint30 = NXOpen.Point3d(63.0, -2.9560789333333091, 0.0)
    endPoint30 = NXOpen.Point3d(63.0, 3.2645504000000329, 0.0)
    line24 = workPart.Curves.CreateLine(startPoint30, endPoint30)
    
    startPoint31 = NXOpen.Point3d(63.0, 3.2645504000000329, 0.0)
    endPoint31 = NXOpen.Point3d(63.0, 3.2645504000000329, -9.9999999999999911)
    line25 = workPart.Curves.CreateLine(startPoint31, endPoint31)
    
    startPoint32 = NXOpen.Point3d(63.0, 3.2645504000000329, -9.9999999999999911)
    endPoint32 = NXOpen.Point3d(63.0, -2.9560789333333091, -9.9999999999999911)
    line26 = workPart.Curves.CreateLine(startPoint32, endPoint32)
    
    startPoint33 = NXOpen.Point3d(63.0, -2.9560789333333091, -9.9999999999999911)
    endPoint33 = NXOpen.Point3d(63.0, -2.9560789333333091, 0.0)
    line27 = workPart.Curves.CreateLine(startPoint33, endPoint33)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line24
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line25
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line25
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line26
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line26
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line27
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line27
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line24
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom16.Geometry = line24
    geom16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateHorizontalConstraint(geom16)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line24
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line25
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line25
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line26
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line26
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line27
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line27
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line24
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_27, conGeom2_27)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line24
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    edge12 = extrude1.FindObject("EDGE * 140 * 170 {(120,-60,0)(120,0,0)(120,60,0) EXTRUDE(2)}")
    conGeom2_28.Geometry = edge12
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 63.0
    help4.Point.Y = -2.9560789333333091
    help4.Point.Z = 0.0
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_28, conGeom2_28, help4)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line26
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    edge13 = extrude2.FindObject("EDGE * 180 * 190 {(63,-5,-10)(63,0,-10)(63,5,-10) EXTRUDE(2)}")
    conGeom2_29.Geometry = edge13
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help5.Point.X = 63.0
    help5.Point.Y = 3.2645504000000347
    help5.Point.Z = -10.0
    help5.Parameter = 0.0
    sketchHelpedGeometricConstraint5 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_29, conGeom2_29, help5)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line25
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line25
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(63.0, 0.24170240000003274, -4.9999999999999956)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_11, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression72 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line24
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line24
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(63.0, 0.15423573333336194, -3.0228480000000002)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_12, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression73 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms20 = [NXOpen.SmartObject.Null] * 4 
    geoms20[0] = line24
    geoms20[1] = line25
    geoms20[2] = line26
    geoms20[3] = line27
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms20)
    
    geoms21 = [NXOpen.SmartObject.Null] * 4 
    geoms21[0] = line24
    geoms21[1] = line25
    geoms21[2] = line26
    geoms21[3] = line27
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms21)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines89 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines92)
    
    theSession.SetUndoMarkName(markId148, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point47 = NXOpen.Point3d(63.0, -2.9560789333333091, -3.0684415999999546)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point47)
    
    point1_86 = NXOpen.Point3d(63.0, -2.9560789333333091, 0.0)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    point1_87 = NXOpen.Point3d(63.0, -2.9560789333333091, -9.9999999999999911)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    point1_88 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    point1_89 = NXOpen.Point3d(63.0, -2.9560789333333091, -3.0684415999999546)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    point1_90 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(63.0, -2.9560789333333091, -3.0684415999999546)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    point1_92 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Destroy()
    
    theSession.UndoToMark(markId148, None)
    
    theSession.DeleteUndoMark(markId148, None)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch11 = theSession.ActiveSketch
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Enter Direct Sketch")
    
    theSession.SetUndoMarkVisibility(markId150, "Enter Direct Sketch", NXOpen.Session.MarkVisibility.Visible)
    
    sketch11.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines97 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines100)
    
    theSession.SetUndoMarkName(markId151, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    point48 = NXOpen.Point3d(63.0, -2.9560789333333091, -5.3710669410180998)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point48)
    
    point1_93 = NXOpen.Point3d(63.0, -2.9560789333333091, -9.9999999999999911)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    point1_94 = NXOpen.Point3d(63.0, -2.9560789333333091, 0.0)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    point1_95 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    point1_96 = NXOpen.Point3d(63.0, -2.9560789333333091, -5.3710669410180998)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    point1_97 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(63.0, -2.9560789333333091, -5.3710669410180998)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    point1_99 = NXOpen.Point3d(63.0, -5.0, -5.0)
    point2_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge10, workPart.ModelingViews.WorkView, point1_99, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_99)
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point49 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point49
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point50 = NXOpen.Point3d(63.0, -3.7928669926886913, -5.3710669410180989)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point50)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = True
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject28 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId152, None)
    
    theSession.SetUndoMarkName(markId151, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId151, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId153, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression74 = workPart.Expressions.FindObject("p26")
    expression74.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId154, None)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId153, "Edit Driving Value")
    
    point1_100 = NXOpen.Point3d(63.0, 3.2206293333333429, -4.9999999999999982)
    point2_100 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line25, workPart.ModelingViews.WorkView, point1_100, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_100)
    
    edge14 = extrude2.FindObject("EDGE * 120 * 180 {(63,5,0)(63,5,-5)(63,5,-10) EXTRUDE(2)}")
    point51 = NXOpen.Point3d(63.0, 5.0, -5.4835724108804342)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(edge14, workPart.ModelingViews.WorkView, point51)
    
    point1_101 = NXOpen.Point3d(63.0, 5.0, -5.4835724108804342)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge14, workPart.ModelingViews.WorkView, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(63.0, 3.2206293333333429, -4.9999999999999982)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line25, workPart.ModelingViews.WorkView, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point52 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point52
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder19.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point53 = NXOpen.Point3d(63.0, 4.3075268373993643, -5.7085833506051014)
    sketchRapidDimensionBuilder19.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point53)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.TextCentered = False
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder19.Commit()
    
    theSession.DeleteUndoMark(markId156, None)
    
    theSession.SetUndoMarkName(markId155, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines105 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines108)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    expression75 = workPart.Expressions.FindObject("p27")
    expression75.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId157, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId158, None)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId157, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder20.Destroy()
    
    theSession.UndoToMark(markId159, None)
    
    theSession.DeleteUndoMark(markId159, None)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    sketch12 = theSession.ActiveSketch
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("28")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies53)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId161, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features6 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature9
    features6[0] = sketchFeature5
    curveFeatureRule6 = workPart.ScRuleFactory.CreateRuleCurveFeature(features6)
    
    section6.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = curveFeatureRule6
    helpPoint6 = NXOpen.Point3d(63.000000000000512, -3.0000000000001013, -4.8935768129523005)
    section6.AddToSection(rules6, line27, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId163, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch12, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction13
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies54)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies55)
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId162, None)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies57)
    
    direction14 = extrudeBuilder6.Direction
    
    success3 = direction14.ReverseDirection()
    
    extrudeBuilder6.Direction = direction14
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies58 = [NXOpen.Body.Null] * 1 
    targetBodies58[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies58)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies59 = [NXOpen.Body.Null] * 1 
    targetBodies59[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies59)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies60 = [NXOpen.Body.Null] * 1 
    targetBodies60[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies60)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies61 = [NXOpen.Body.Null] * 1 
    targetBodies61[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies61)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies62 = [NXOpen.Body.Null] * 1 
    targetBodies62[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies62)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies63 = [NXOpen.Body.Null] * 1 
    targetBodies63[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies63)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies64 = [NXOpen.Body.Null] * 1 
    targetBodies64[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies64)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies65 = [NXOpen.Body.Null] * 1 
    targetBodies65[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies65)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies66 = [NXOpen.Body.Null] * 1 
    targetBodies66[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies66)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies67 = [NXOpen.Body.Null] * 1 
    targetBodies67[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies67)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("149")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies68 = [NXOpen.Body.Null] * 1 
    targetBodies68[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies68)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId164, None)
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId165, None)
    
    theSession.SetUndoMarkName(markId161, "Extrude")
    
    expression78 = extrudeBuilder6.Limits.StartExtend.Value
    expression79 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression76)
    
    workPart.Expressions.Delete(expression77)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.37167783993156217
    rotMatrix19.Xy = 0.9277250737621634
    rotMatrix19.Xz = -0.034376893646818646
    rotMatrix19.Yx = -0.05498759546794238
    rotMatrix19.Yy = 0.058964289695574247
    rotMatrix19.Yz = 0.99674448926761339
    rotMatrix19.Zx = 0.92673186394364915
    rotMatrix19.Zy = -0.36857753601337934
    rotMatrix19.Zz = 0.072929090888650766
    translation19 = NXOpen.Point3d(-8.5616766799584632, 7.5502532191911502, -11.362458559354607)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 2.977324695121951)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects6 = [NXOpen.DisplayableObject.Null] * 5 
    objects6[0] = sketch12
    objects6[1] = line24
    objects6[2] = line25
    objects6[3] = line26
    objects6[4] = line27
    theSession.DisplayManager.BlankObjects(objects6)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.80749132122523426
    rotMatrix20.Xy = 0.58987054995392119
    rotMatrix20.Xz = 0.0032404387024825791
    rotMatrix20.Yx = 0.038486892078691409
    rotMatrix20.Yy = -0.058165946485570184
    rotMatrix20.Yz = 0.99756477574519498
    rotMatrix20.Zx = 0.58862256606763674
    rotMatrix20.Zy = -0.8054001843596118
    rotMatrix20.Zz = -0.069670781174424268
    translation20 = NXOpen.Point3d(-34.710485557578792, 1.9417839663931229, 8.9240993132061348)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 2.977324695121951)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.4806845542786502
    rotMatrix21.Xy = 0.87418455142747553
    rotMatrix21.Xz = 0.068874736467597161
    rotMatrix21.Yx = 0.71100262885676924
    rotMatrix21.Yy = -0.43451594443073005
    rotMatrix21.Yz = 0.55287535285472345
    rotMatrix21.Zx = 0.5132422634942484
    rotMatrix21.Zy = -0.21678852386834493
    rotMatrix21.Zz = -0.8304126172465619
    translation21 = NXOpen.Point3d(-15.102079540783748, -38.409160240291548, 13.446917467609438)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 2.977324695121951)
    
    origin32 = NXOpen.Point3d(25.378729766530743, -19.932092133727036, 37.082050982045793)
    workPart.ModelingViews.WorkView.SetOrigin(origin32)
    
    origin33 = NXOpen.Point3d(25.378729766530743, -19.932092133727036, 37.082050982045793)
    workPart.ModelingViews.WorkView.SetOrigin(origin33)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin34, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane16
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression81 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId167, "Create Sketch Dialog")
    
    scalar7 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge15 = extrude2.FindObject("EDGE * 160 EXTRUDE(2) 140 {(57,-5,0)(57,-4,0)(57,-3,0) EXTRUDE(2)}")
    point54 = workPart.Points.CreatePoint(edge15, scalar7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction15 = workPart.Directions.CreateDirection(edge11, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face5 = extrude1.FindObject("FACE 140 {(60,0,0) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face5, direction15, point54, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem6
    
    origin35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin35, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane17.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom17 = [NXOpen.NXObject.Null] * 1 
    geom17[0] = face5
    plane17.SetGeometry(geom17)
    
    plane17.SetFlip(False)
    
    plane17.SetExpression(None)
    
    plane17.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane17.Evaluate()
    
    origin36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin36, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane18.SynchronizeToPlane(plane17)
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point55 = workPart.Points.CreatePoint(edge15, scalar8, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane18.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face5
    plane18.SetGeometry(geom18)
    
    plane18.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane18.Evaluate()
    
    # ----------------------------------------------
    #   Menu: OK
    # ----------------------------------------------
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId168, None)
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject30 = sketchInPlaceBuilder6.Commit()
    
    sketch13 = nXObject30
    feature11 = sketch13.Feature
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId170)
    
    sketch13.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId169, None)
    
    theSession.SetUndoMarkName(markId167, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression81)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point55)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression80)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression83)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression82)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane18.DestroyPlane()
    
    origin37 = NXOpen.Point3d(55.311543466666443, -21.617966933333811, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin37)
    
    origin38 = NXOpen.Point3d(55.311543466666443, -21.617966933333811, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin38)
    
    scaleAboutPoint37 = NXOpen.Point3d(3.1103146666666941, 9.7752746666667036, 0.0)
    viewCenter37 = NXOpen.Point3d(-3.1103146666666182, -9.775274666666629, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(3.8878933333333672, 12.330176000000026, 0.0)
    viewCenter38 = NXOpen.Point3d(-3.8878933333332819, -12.33017599999997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(4.9987200000000467, 15.82928000000002, 0.0)
    viewCenter39 = NXOpen.Point3d(-4.9987199999999516, -15.829279999999962, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    origin39 = NXOpen.Point3d(55.200460799999526, -12.814665600001126, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin39)
    
    origin40 = NXOpen.Point3d(55.200460799999526, -12.814665600001126, 0.0)
    workPart.ModelingViews.WorkView.SetOrigin(origin40)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId172, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint34 = NXOpen.Point3d(68.0, -52.0, 0.0)
    endPoint34 = NXOpen.Point3d(68.0, -44.0, 0.0)
    line28 = workPart.Curves.CreateLine(startPoint34, endPoint34)
    
    startPoint35 = NXOpen.Point3d(68.0, -44.0, 0.0)
    endPoint35 = NXOpen.Point3d(52.0, -44.0, 0.0)
    line29 = workPart.Curves.CreateLine(startPoint35, endPoint35)
    
    startPoint36 = NXOpen.Point3d(52.0, -44.0, 0.0)
    endPoint36 = NXOpen.Point3d(52.0, -52.0, 0.0)
    line30 = workPart.Curves.CreateLine(startPoint36, endPoint36)
    
    startPoint37 = NXOpen.Point3d(52.0, -52.0, 0.0)
    endPoint37 = NXOpen.Point3d(68.0, -52.0, 0.0)
    line31 = workPart.Curves.CreateLine(startPoint37, endPoint37)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line29, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line30, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line31, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line28
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_26.Geometry = line29
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint56 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line29
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = line30
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint57 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    geom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_28.Geometry = line30
    geom1_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_28.SplineDefiningPointIndex = 0
    geom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_28.Geometry = line31
    geom2_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint58 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_28, geom2_28)
    
    geom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_29.Geometry = line31
    geom1_29.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_29.SplineDefiningPointIndex = 0
    geom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_29.Geometry = line28
    geom2_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint59 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_29, geom2_29)
    
    geom19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom19.Geometry = line28
    geom19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint60 = theSession.ActiveSketch.CreateHorizontalConstraint(geom19)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line28
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_30.Geometry = line29
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint61 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_30, conGeom2_30)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line29
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_31.Geometry = line30
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint62 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_31, conGeom2_31)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line30
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = line31
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint63 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_32, conGeom2_32)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line31
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = line28
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint64 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_33, conGeom2_33)
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = line28
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line28
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(62.096000000000004, -48.0, 0.0)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_15, dimObject2_13, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint15
    dimension15 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression84 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line29
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line29
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 0.0
    dimObject2_14.HelpPoint.Y = 0.0
    dimObject2_14.HelpPoint.Z = 0.0
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(60.0, -49.903999999999996, 0.0)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_14, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint15 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint15.AssociatedDimension
    
    expression85 = sketchHelpedDimensionalConstraint15.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms22 = [NXOpen.SmartObject.Null] * 4 
    geoms22[0] = line28
    geoms22[1] = line29
    geoms22[2] = line30
    geoms22[3] = line31
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms22)
    
    geoms23 = [NXOpen.SmartObject.Null] * 4 
    geoms23[0] = line28
    geoms23[1] = line29
    geoms23[2] = line30
    geoms23[3] = line31
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms23)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    scaleAboutPoint40 = NXOpen.Point3d(8.3312000000000435, 5.5541333333333496, 0.0)
    viewCenter40 = NXOpen.Point3d(-8.3311999999999546, -5.5541333333333052, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(10.630958333333375, 7.3765833333333566, 0.0)
    viewCenter41 = NXOpen.Point3d(-10.630958333333282, -7.3765833333333006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(13.559895833333345, 9.2207291666666951, 0.0)
    viewCenter42 = NXOpen.Point3d(-13.559895833333252, -9.2207291666666489, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(10.847916666666695, 7.3765833333333566, 0.0)
    viewCenter43 = NXOpen.Point3d(-10.847916666666602, -7.3765833333333193, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(8.6783333333333577, 5.9012666666666709, 0.0)
    viewCenter44 = NXOpen.Point3d(-8.6783333333332688, -5.9012666666666558, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(7.2203733333334092, 3.3324800000000123, 0.0)
    viewCenter45 = NXOpen.Point3d(-7.2203733333332547, -3.3324799999999883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(5.7762986666667357, 2.5549013333333397, 0.0)
    viewCenter46 = NXOpen.Point3d(-5.7762986666665848, -2.5549013333333299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(6.309495466666724, -0.97752746666666401, 0.0)
    viewCenter47 = NXOpen.Point3d(-6.3094954666665872, 0.97752746666666401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(3.6257382400000724, -0.1421858133333313, 0.0)
    viewCenter48 = NXOpen.Point3d(-3.6257382399999267, 0.1421858133333313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId174, "Curve")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId176, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint38 = NXOpen.Point3d(60.000000000000007, -5.0, 0.0)
    endPoint38 = NXOpen.Point3d(60.00000000000005, -44.0, 0.0)
    line32 = workPart.Curves.CreateLine(startPoint38, endPoint38)
    
    theSession.ActiveSketch.AddGeometry(line32, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_30.Geometry = line32
    geom1_30.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_30.SplineDefiningPointIndex = 0
    geom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_30.Geometry = edge9
    geom2_30.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint65 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_30, geom2_30)
    
    geom20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom20.Geometry = line32
    geom20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint66 = theSession.ActiveSketch.CreateHorizontalConstraint(geom20)
    
    geom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_31.Geometry = line32
    geom1_31.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_31.SplineDefiningPointIndex = 0
    geom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_31.Geometry = line29
    geom2_31.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint67 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_31, geom2_31)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = -0.12368820899274538
    rotMatrix22.Xy = 0.98695581550375711
    rotMatrix22.Xz = 0.10305069237749914
    rotMatrix22.Yx = 0.99184961882791212
    rotMatrix22.Yy = 0.12616196919972544
    rotMatrix22.Yz = -0.017818281583076676
    rotMatrix22.Zx = -0.030586934908441235
    rotMatrix22.Zy = 0.10000687861823533
    rotMatrix22.Zz = -0.99451649742070503
    translation22 = NXOpen.Point3d(13.772887414899333, -56.932008207007549, 1.8352160945064742)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 4.6520698361280495)
    
    origin41 = NXOpen.Point3d(58.188228701542599, -20.912967339203014, -2.0472501569801778)
    workPart.ModelingViews.WorkView.SetOrigin(origin41)
    
    origin42 = NXOpen.Point3d(58.188228701542599, -20.912967339203014, -2.0472501569801778)
    workPart.ModelingViews.WorkView.SetOrigin(origin42)
    
    # ----------------------------------------------
    #   Menu: Orient View->Front
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Front, NXOpen.View.ScaleAdjustment.Fit)
    
    # ----------------------------------------------
    #   Menu: Orient View->Bottom
    # ----------------------------------------------
    workPart.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Bottom, NXOpen.View.ScaleAdjustment.Fit)
    
    scaleAboutPoint49 = NXOpen.Point3d(20.499999999999986, 56.374999999999979, 0.0)
    viewCenter49 = NXOpen.Point3d(-20.499999999999986, -56.374999999999979, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint49, viewCenter49)
    
    origin43 = NXOpen.Point3d(66.556985294117666, -21.517463235293985, 1.1764705882353041)
    workPart.ModelingViews.WorkView.SetOrigin(origin43)
    
    origin44 = NXOpen.Point3d(66.556985294117666, -21.517463235293985, 1.1764705882353041)
    workPart.ModelingViews.WorkView.SetOrigin(origin44)
    
    scaleAboutPoint50 = NXOpen.Point3d(2.8262867647058809, 26.378676470588239, 0.0)
    viewCenter50 = NXOpen.Point3d(-2.8262867647058809, -26.378676470588225, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-2.1197150735294508, 35.328584558823515, 0.0)
    viewCenter51 = NXOpen.Point3d(2.1197150735293704, -35.328584558823493, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(-1.8841911764706247, 26.567095588235279, 0.0)
    viewCenter52 = NXOpen.Point3d(1.8841911764705606, -26.567095588235279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-1.6580882352941513, 21.102941176470583, 0.0)
    viewCenter53 = NXOpen.Point3d(1.6580882352941, -21.102941176470583, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-1.3264705882353209, 16.882352941176464, 0.0)
    viewCenter54 = NXOpen.Point3d(1.3264705882352799, -16.882352941176464, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-1.0611764705882567, 14.277647058823526, 0.0)
    viewCenter55 = NXOpen.Point3d(1.0611764705882238, -14.277647058823526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(0.84894117647055256, 11.962352941176476, 0.0)
    viewCenter56 = NXOpen.Point3d(-0.84894117647060519, -11.962352941176457, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(0.67915294117643144, 9.940329411764715, 0.0)
    viewCenter57 = NXOpen.Point3d(-0.67915294117649461, -9.940329411764683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    origin45 = NXOpen.Point3d(64.546104117646991, -48.062207794117363, 1.1764705882353041)
    workPart.ModelingViews.WorkView.SetOrigin(origin45)
    
    origin46 = NXOpen.Point3d(64.546104117646991, -48.062207794117363, 1.1764705882353041)
    workPart.ModelingViews.WorkView.SetOrigin(origin46)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines113 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId177, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    point1_103 = NXOpen.Point3d(60.0, -52.0, 0.0)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line31, workPart.ModelingViews.WorkView, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    point1_104 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge5, workPart.ModelingViews.WorkView, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    point1_105 = NXOpen.Point3d(60.0, -52.0, 0.0)
    point2_105 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line31, workPart.ModelingViews.WorkView, point1_105, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_105)
    
    point1_106 = NXOpen.Point3d(60.0, -60.0, 0.0)
    point2_106 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge5, workPart.ModelingViews.WorkView, point1_106, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_106)
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point56 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point56
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point57 = NXOpen.Point3d(60.29831117647052, -56.607186617646818, 0.0)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point57)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = True
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject31 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId178, None)
    
    theSession.SetUndoMarkName(markId177, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId177, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId179, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    expression86 = workPart.Expressions.FindObject("p30")
    expression86.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId179, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId180, None)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId179, "Edit Driving Value")
    
    parallelDimension11 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    point58 = NXOpen.Point3d(61.53313470588229, -45.118945824926527, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(parallelDimension11, workPart.ModelingViews.WorkView, point58)
    
    point1_107 = NXOpen.Point3d(68.0, -44.0, 0.0)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, NXOpen.View.Null, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    point1_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    sketchRapidDimensionBuilder22.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder9 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList9 = convertToFromReferenceBuilder9.InputObjects
    
    added9 = selectNXObjectList9.Add(parallelDimension11)
    
    convertToFromReferenceBuilder9.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject32 = convertToFromReferenceBuilder9.Commit()
    
    convertToFromReferenceBuilder9.Destroy()
    
    parallelDimension12 = nXObject32
    point59 = NXOpen.Point3d(61.582527647058761, -45.118945824926527, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(parallelDimension12, workPart.ModelingViews.WorkView, point59)
    
    point1_109 = NXOpen.Point3d(68.0, -44.0, 0.0)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, NXOpen.View.Null, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    point1_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    theSession.UndoToMark(markId181, None)
    
    theSession.DeleteUndoMark(markId181, None)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines125 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines128)
    
    theSession.SetUndoMarkName(markId182, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    point60 = NXOpen.Point3d(68.0, -47.667064264705644, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(line28, workPart.ModelingViews.WorkView, point60)
    
    point1_111 = NXOpen.Point3d(68.0, -44.0, 0.0)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line28, workPart.ModelingViews.WorkView, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(68.0, -56.0, 0.0)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line28, workPart.ModelingViews.WorkView, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    point1_113 = NXOpen.Point3d(60.00000000000005, -44.0, 0.0)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line32, workPart.ModelingViews.WorkView, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(68.0, -47.667064264705644, 0.0)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line28, workPart.ModelingViews.WorkView, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    point1_115 = NXOpen.Point3d(60.00000000000005, -44.0, 0.0)
    point2_115 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line32, workPart.ModelingViews.WorkView, point1_115, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_115)
    
    point1_116 = NXOpen.Point3d(68.0, -47.667064264705644, 0.0)
    point2_116 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line28, workPart.ModelingViews.WorkView, point1_116, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_116)
    
    point1_117 = NXOpen.Point3d(60.00000000000005, -44.0, 0.0)
    point2_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line32, workPart.ModelingViews.WorkView, point1_117, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_117)
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point61 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point61
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point62 = NXOpen.Point3d(66.176071176470529, -40.554480735293872, 0.0)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point62)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject33 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId183, None)
    
    theSession.SetUndoMarkName(markId182, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId182, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines129 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines132)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId184, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension5 = nXObject33
    point63 = NXOpen.Point3d(66.225464117646993, -39.99328871862707, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(perpendicularDimension5, workPart.ModelingViews.WorkView, point63)
    
    point1_118 = NXOpen.Point3d(68.0, -47.667064264705644, 0.0)
    point2_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line28, NXOpen.View.Null, point1_118, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_118)
    
    point1_119 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_119 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_119, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_119)
    
    sketchRapidDimensionBuilder24.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression87 = workPart.Expressions.FindObject("p31")
    expression87.SetFormula("5")
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId185, None)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId184, "Edit Driving Value")
    
    point64 = NXOpen.Point3d(60.00000000000005, -42.283233676470346, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(line32, workPart.ModelingViews.WorkView, point64)
    
    point1_120 = NXOpen.Point3d(60.00000000000005, -44.0, 0.0)
    point2_120 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line32, workPart.ModelingViews.WorkView, point1_120, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_120)
    
    point1_121 = NXOpen.Point3d(60.000000000000007, -5.0, 0.0)
    point2_121 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line32, workPart.ModelingViews.WorkView, point1_121, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_121)
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    point1_122 = NXOpen.Point3d(55.0, -44.0, 0.0)
    point2_122 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line30, workPart.ModelingViews.WorkView, point1_122, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_122)
    
    point1_123 = NXOpen.Point3d(60.00000000000005, -42.283233676470346, 0.0)
    point2_123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line32, workPart.ModelingViews.WorkView, point1_123, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_123)
    
    point1_124 = NXOpen.Point3d(55.0, -44.0, 0.0)
    point2_124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line30, workPart.ModelingViews.WorkView, point1_124, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_124)
    
    point1_125 = NXOpen.Point3d(60.00000000000005, -42.283233676470346, 0.0)
    point2_125 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line32, workPart.ModelingViews.WorkView, point1_125, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_125)
    
    point1_126 = NXOpen.Point3d(55.0, -44.0, 0.0)
    point2_126 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line30, workPart.ModelingViews.WorkView, point1_126, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_126)
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point65 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point65
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point66 = NXOpen.Point3d(57.581699411764639, -41.937483088235055, 0.0)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point66)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = True
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject34 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId187, None)
    
    theSession.SetUndoMarkName(markId186, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId188, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Destroy()
    
    theSession.UndoToMark(markId188, None)
    
    theSession.DeleteUndoMark(markId188, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines137 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines140)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines141 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines141)
    
    lines142 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines142)
    
    lines143 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines143)
    
    lines144 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines144)
    
    theSession.SetUndoMarkName(markId189, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    point67 = NXOpen.Point3d(62.718565294117582, -44.000000000000007, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(line29, workPart.ModelingViews.WorkView, point67)
    
    point1_127 = NXOpen.Point3d(65.0, -44.000000000000007, 0.0)
    point2_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, workPart.ModelingViews.WorkView, point1_127, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_127)
    
    point1_128 = NXOpen.Point3d(55.0, -44.0, 0.0)
    point2_128 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line29, workPart.ModelingViews.WorkView, point1_128, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_128)
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    point1_129 = NXOpen.Point3d(59.999999999999993, -56.0, 0.0)
    point2_129 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line31, workPart.ModelingViews.WorkView, point1_129, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_129)
    
    point1_130 = NXOpen.Point3d(62.718565294117582, -44.000000000000007, 0.0)
    point2_130 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line29, workPart.ModelingViews.WorkView, point1_130, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_130)
    
    point1_131 = NXOpen.Point3d(59.999999999999993, -56.0, 0.0)
    point2_131 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line31, workPart.ModelingViews.WorkView, point1_131, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_131)
    
    point1_132 = NXOpen.Point3d(62.718565294117582, -44.000000000000007, 0.0)
    point2_132 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line29, workPart.ModelingViews.WorkView, point1_132, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_132)
    
    point1_133 = NXOpen.Point3d(59.999999999999993, -56.0, 0.0)
    point2_133 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder26.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line31, workPart.ModelingViews.WorkView, point1_133, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_133)
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point68 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point68
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder26.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point69 = NXOpen.Point3d(59.508024117646997, -51.27274897058799, 0.0)
    sketchRapidDimensionBuilder26.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point69)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.TextCentered = False
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject35 = sketchRapidDimensionBuilder26.Commit()
    
    theSession.DeleteUndoMark(markId190, None)
    
    theSession.SetUndoMarkName(markId189, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId189, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder27 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines145 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines145)
    
    lines146 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines146)
    
    lines147 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines147)
    
    lines148 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines148)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder27.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId191, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder27.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits833 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits834 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits835 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits836 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits837 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits838 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits839 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits840 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits841 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits842 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder27.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits843 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits844 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits845 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits846 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits847 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits848 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits849 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits850 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits851 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits852 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    expression88 = workPart.Expressions.FindObject("p33")
    expression88.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId192, None)
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId191, "Edit Driving Value")
    
    sketchRapidDimensionBuilder27.Destroy()
    
    theSession.UndoToMark(markId193, None)
    
    theSession.DeleteUndoMark(markId193, None)
    
    sketchRapidDimensionBuilder27.Destroy()
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects7 = [NXOpen.TaggedObject.Null] * 1 
    objects7[0] = line32
    nErrs11 = theSession.UpdateManager.AddObjectsToDeleteList(objects7)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs12 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId194, None)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch14 = theSession.ActiveSketch
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression89 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies69 = [NXOpen.Body.Null] * 1 
    targetBodies69[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies69)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("149")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies70 = [NXOpen.Body.Null] * 1 
    targetBodies70[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies70)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId197, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features7 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature6 = feature11
    features7[0] = sketchFeature6
    curveFeatureRule7 = workPart.ScRuleFactory.CreateRuleCurveFeature(features7)
    
    section7.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = curveFeatureRule7
    helpPoint7 = NXOpen.Point3d(59.556348989924416, -50.00000000000005, 2.8421709430404007e-14)
    section7.AddToSection(rules7, line29, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId199, None)
    
    direction16 = workPart.Directions.CreateDirection(sketch14, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction16
    
    targetBodies71 = [NXOpen.Body.Null] * 1 
    targetBodies71[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies71)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies72 = [NXOpen.Body.Null] * 1 
    targetBodies72[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies72)
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId198, None)
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies73 = [NXOpen.Body.Null] * 1 
    targetBodies73[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies73)
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId200, None)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature12 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId201, None)
    
    theSession.SetUndoMarkName(markId197, "Extrude")
    
    expression91 = extrudeBuilder7.Limits.StartExtend.Value
    expression92 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression89)
    
    workPart.Expressions.Delete(expression90)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.70023244039602583
    rotMatrix23.Xy = 0.69284113836802408
    rotMatrix23.Xz = -0.17217922755643017
    rotMatrix23.Yx = 0.35913769317009964
    rotMatrix23.Yy = -0.13341891652557947
    rotMatrix23.Yz = 0.92369881999361747
    rotMatrix23.Zx = 0.61700457596478731
    rotMatrix23.Zy = -0.70863992951148569
    rotMatrix23.Zz = -0.34224962168053746
    translation23 = NXOpen.Point3d(-10.501726041158779, -26.0950112990908, 7.2211787193771002)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 2.977324695121951)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin47, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane19
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression94 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId202, "Create Sketch Dialog")
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude4 = feature12
    edge16 = extrude4.FindObject("EDGE * 130 * 150 {(65,-50,-10)(65,-53,-10)(65,-56,-10) EXTRUDE(2)}")
    point70 = workPart.Points.CreatePoint(edge16, scalar9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge17 = extrude4.FindObject("EDGE * 150 EXTRUDE(2) 140 {(65,-50,0)(65,-53,0)(65,-56,0) EXTRUDE(2)}")
    direction17 = workPart.Directions.CreateDirection(edge17, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face6 = extrude4.FindObject("FACE 150 {(65,-53,-5) EXTRUDE(2)}")
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction17, point70, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem7
    
    origin48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal20 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane20 = workPart.Planes.CreatePlane(origin48, normal20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane20.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom21 = [NXOpen.NXObject.Null] * 1 
    geom21[0] = face6
    plane20.SetGeometry(geom21)
    
    plane20.SetFlip(False)
    
    plane20.SetExpression(None)
    
    plane20.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane20.Evaluate()
    
    origin49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal21 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin49, normal21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane21.SynchronizeToPlane(plane20)
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point71 = workPart.Points.CreatePoint(edge16, scalar10, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane21.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom22 = [NXOpen.NXObject.Null] * 1 
    geom22[0] = face6
    plane21.SetGeometry(geom22)
    
    plane21.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane21.Evaluate()
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId203, None)
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject36 = sketchInPlaceBuilder7.Commit()
    
    sketch15 = nXObject36
    feature13 = sketch15.Feature
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs13 = theSession.UpdateManager.DoUpdate(markId205)
    
    sketch15.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId204, None)
    
    theSession.SetUndoMarkName(markId202, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression94)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point71)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression93)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression96)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression95)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane21.DestroyPlane()
    
    scaleAboutPoint58 = NXOpen.Point3d(0.88866133333336605, 5.2431018666667049, 0.0)
    viewCenter58 = NXOpen.Point3d(-0.88866133333329023, -5.2431018666666294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(1.2219093333333677, 8.7755306666667057, 0.0)
    viewCenter59 = NXOpen.Point3d(-1.2219093333332827, -8.7755306666666311, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(0.62206293333336604, 7.1981568000000369, 0.0)
    viewCenter60 = NXOpen.Point3d(-0.62206293333329032, -7.1981567999999614, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(0.49765034666670499, 5.7585254400000361, 0.0)
    viewCenter61 = NXOpen.Point3d(-0.49765034666662622, -5.758525439999957, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(0.34124595200003877, 4.4361973760000382, 0.0)
    viewCenter62 = NXOpen.Point3d(-0.34124595199995145, -4.4361973759999609, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(0.27299676160003489, 3.5489579008000383, 0.0)
    viewCenter63 = NXOpen.Point3d(-0.27299676159996505, -3.548957900799961, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(0.14559827285336535, 2.8027667524267037, 0.0)
    viewCenter64 = NXOpen.Point3d(-0.14559827285328467, -2.802766752426626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId207, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(64.999999999999986, -53.100000000000009, -5.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.674474484005205, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = arc3
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(64.999999999999986, -53.100000000000009, -4.6698243891200004)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_17, dimOrigin17, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension17 = sketchDimensionalConstraint17.AssociatedDimension
    
    expression97 = sketchDimensionalConstraint17.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder28 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines149 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines149)
    
    lines150 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines150)
    
    lines151 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines151)
    
    lines152 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines152)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder28.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines153 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines153)
    
    lines154 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines154)
    
    lines155 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines155)
    
    lines156 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines156)
    
    theSession.SetUndoMarkName(markId208, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder28.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits853 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits854 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits855 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits856 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits857 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits858 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits859 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits860 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits861 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits862 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder28.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits863 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits864 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits865 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits866 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits867 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits868 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits869 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits870 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits871 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits872 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    point1_134 = NXOpen.Point3d(64.999999999999986, -53.100000000000009, -5.0)
    point2_134 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_134, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_134)
    
    point1_135 = NXOpen.Point3d(64.999999999999986, -53.100000000000009, -5.0)
    point2_135 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_135, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_135)
    
    point1_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_136, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_136)
    
    dimensionlinearunits873 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits874 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits875 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits876 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits877 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits878 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point72 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point72
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder28.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point73 = NXOpen.Point3d(64.999999999999986, -47.155821629439984, -4.0787571152212827)
    sketchRapidDimensionBuilder28.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point73)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.TextCentered = False
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject37 = sketchRapidDimensionBuilder28.Commit()
    
    theSession.DeleteUndoMark(markId209, None)
    
    theSession.SetUndoMarkName(markId208, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId208, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder28.Destroy()
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder29 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines157 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines157)
    
    lines158 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines158)
    
    lines159 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines159)
    
    lines160 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines160)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder29.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId210, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder29.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits879 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits880 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits881 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits882 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits883 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits884 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits885 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits886 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits887 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits888 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder29.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits889 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits890 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits891 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits892 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits893 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits894 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits895 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits896 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits897 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits898 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    expression98 = workPart.Expressions.FindObject("p36")
    expression98.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId210, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.89580343822994968)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId211, None)
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId210, "Edit Driving Value")
    
    point1_137 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -5.5209828088502517)
    point2_137 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_137, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_137)
    
    point1_138 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -5.5209828088502517)
    point2_138 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_138, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_138)
    
    point1_139 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_139 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_139, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_139)
    
    dimensionlinearunits899 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits900 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits901 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits902 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits903 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits904 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    point74 = NXOpen.Point3d(65.0, -53.300068743850652, -10.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(edge16, workPart.ModelingViews.WorkView, point74)
    
    point1_140 = NXOpen.Point3d(65.0, -53.300068743850652, -10.0)
    point2_140 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge16, workPart.ModelingViews.WorkView, point1_140, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_140)
    
    point1_141 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -5.5209828088502517)
    point2_141 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_141, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_141)
    
    point1_142 = NXOpen.Point3d(65.0, -53.300068743850652, -10.0)
    point2_142 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge16, workPart.ModelingViews.WorkView, point1_142, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_142)
    
    point1_143 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -5.5209828088502517)
    point2_143 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_143, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_143)
    
    dimensionlinearunits905 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits906 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits907 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits908 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits909 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits910 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits911 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits912 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits913 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits914 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits915 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits916 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point75 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point75
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder29.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point76 = NXOpen.Point3d(64.999999999999986, -60.754700313941321, -8.1263891005439497)
    sketchRapidDimensionBuilder29.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point76)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.TextCentered = True
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject38 = sketchRapidDimensionBuilder29.Commit()
    
    theSession.DeleteUndoMark(markId213, None)
    
    theSession.SetUndoMarkName(markId212, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId212, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder29.Destroy()
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder30 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines161 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBefore(lines161)
    
    lines162 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAfter(lines162)
    
    lines163 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAbove(lines163)
    
    lines164 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBelow(lines164)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder30.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId214, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder30.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits917 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits918 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits919 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits920 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits921 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits922 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits923 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits924 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits925 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits926 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder30.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits927 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits928 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits929 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits930 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits931 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits932 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits933 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits934 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits935 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits936 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    expression99 = workPart.Expressions.FindObject("p37")
    expression99.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId214, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId215, None)
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId214, "Edit Driving Value")
    
    point1_144 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -7.0)
    point2_144 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_144, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_144)
    
    point1_145 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -7.0)
    point2_145 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_145, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_145)
    
    point1_146 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_146 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_146, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_146)
    
    dimensionlinearunits937 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits938 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits939 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits940 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits941 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits942 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    edge18 = extrude4.FindObject("EDGE * 150 * 160 {(65,-56,-10)(65,-56,-5)(65,-56,0) EXTRUDE(2)}")
    point77 = NXOpen.Point3d(65.0, -56.0, -5.6803381166079507)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(edge18, workPart.ModelingViews.WorkView, point77)
    
    point1_147 = NXOpen.Point3d(65.0, -56.0, -5.6803381166079507)
    point2_147 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_147, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_147)
    
    point1_148 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -7.0)
    point2_148 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_148, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_148)
    
    point1_149 = NXOpen.Point3d(65.0, -56.0, -5.6803381166079507)
    point2_149 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge18, workPart.ModelingViews.WorkView, point1_149, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_149)
    
    point1_150 = NXOpen.Point3d(64.999999999999986, -52.776990658512851, -7.0)
    point2_150 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder30.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_150, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_150)
    
    dimensionlinearunits943 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits944 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits945 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits946 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits947 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits948 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits949 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits950 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits951 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits952 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits953 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits954 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point78 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point78
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder30.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point79 = NXOpen.Point3d(64.999999999999986, -53.707743907839983, -4.2534750426452828)
    sketchRapidDimensionBuilder30.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point79)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.TextCentered = False
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject39 = sketchRapidDimensionBuilder30.Commit()
    
    theSession.DeleteUndoMark(markId217, None)
    
    theSession.SetUndoMarkName(markId216, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId216, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder30.Destroy()
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder31 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines165 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBefore(lines165)
    
    lines166 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAfter(lines166)
    
    lines167 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAbove(lines167)
    
    lines168 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBelow(lines168)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder31.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId218, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder31.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits955 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits956 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits957 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits958 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits959 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits960 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits961 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits962 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits963 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits964 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder31.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits965 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits966 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits967 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits968 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits969 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits970 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits971 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits972 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits973 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits974 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension6 = nXObject39
    point80 = NXOpen.Point3d(130.0, -53.707743907839983, -4.2534750426452828)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(perpendicularDimension6, workPart.ModelingViews.WorkView, point80)
    
    line33 = theSession.ActiveSketch.FindObject("Curve EDGE17")
    point1_151 = NXOpen.Point3d(65.0, -56.0, -5.6803381166079507)
    point2_151 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line33, NXOpen.View.Null, point1_151, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_151)
    
    point1_152 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_152 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_152, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_152)
    
    sketchRapidDimensionBuilder31.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression100 = workPart.Expressions.FindObject("p38")
    expression100.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId218, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId219, None)
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId218, "Edit Driving Value")
    
    expression100.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId220, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId221, None)
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId220, "Edit Driving Value")
    
    perpendicularDimension7 = nXObject38
    point81 = NXOpen.Point3d(130.0, -60.929418241365319, -8.3011070279679515)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(perpendicularDimension7, workPart.ModelingViews.WorkView, point81)
    
    line34 = theSession.ActiveSketch.FindObject("Curve EDGE16")
    point1_153 = NXOpen.Point3d(65.0, -53.300068743850652, -10.0)
    point2_153 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line34, NXOpen.View.Null, point1_153, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_153)
    
    point1_154 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_154 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_154, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_154)
    
    sketchRapidDimensionBuilder31.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression99.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId222, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId223, None)
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId222, "Edit Driving Value")
    
    sketchRapidDimensionBuilder31.Destroy()
    
    theSession.UndoToMark(markId224, None)
    
    theSession.DeleteUndoMark(markId224, None)
    
    sketchRapidDimensionBuilder31.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch16 = theSession.ActiveSketch
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 0.43459935902759894
    rotMatrix24.Xy = 0.89975554823773607
    rotMatrix24.Xz = -0.039539227966842963
    rotMatrix24.Yx = 0.27224353553501801
    rotMatrix24.Yy = -0.089397228892639943
    rotMatrix24.Yz = 0.95806659101844915
    rotMatrix24.Zx = 0.85849103343727218
    rotMatrix24.Zy = -0.42713942557639267
    rotMatrix24.Zz = -0.28380460994507378
    translation24 = NXOpen.Point3d(5.436258840946838, -20.881361840985903, -7.2680087289719921)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 2.977324695121951)
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects8 = [NXOpen.DisplayableObject.Null] * 5 
    objects8[0] = line28
    objects8[1] = line29
    objects8[2] = line30
    objects8[3] = line31
    objects8[4] = sketch14
    theSession.DisplayManager.BlankObjects(objects8)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression101 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies74 = [NXOpen.Body.Null] * 1 
    targetBodies74[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies74)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies75 = [NXOpen.Body.Null] * 1 
    targetBodies75[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies75)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId227, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features8 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature7 = feature13
    features8[0] = sketchFeature7
    curveFeatureRule8 = workPart.ScRuleFactory.CreateRuleCurveFeature(features8)
    
    section8.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = curveFeatureRule8
    helpPoint8 = NXOpen.Point3d(64.999999999999986, -51.673094666163159, -5.3118156768124516)
    section8.AddToSection(rules8, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId229, None)
    
    direction18 = workPart.Directions.CreateDirection(sketch16, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction18
    
    targetBodies76 = [NXOpen.Body.Null] * 1 
    targetBodies76[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies76)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies77 = [NXOpen.Body.Null] * 1 
    targetBodies77[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies77)
    
    expression102 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId228, None)
    
    direction19 = extrudeBuilder8.Direction
    
    success4 = direction19.ReverseDirection()
    
    extrudeBuilder8.Direction = direction19
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies78 = [NXOpen.Body.Null] * 1 
    targetBodies78[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies78)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies79 = [NXOpen.Body.Null] * 1 
    targetBodies79[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies79)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies80 = [NXOpen.Body.Null] * 1 
    targetBodies80[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies80)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies81 = [NXOpen.Body.Null] * 1 
    targetBodies81[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies81)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("29")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies82 = [NXOpen.Body.Null] * 1 
    targetBodies82[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies82)
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId230, None)
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature14 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId231, None)
    
    theSession.SetUndoMarkName(markId227, "Extrude")
    
    expression103 = extrudeBuilder8.Limits.StartExtend.Value
    expression104 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression101)
    
    workPart.Expressions.Delete(expression102)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.52250396709964297
    rotMatrix25.Xy = 0.85023172454391416
    rotMatrix25.Xz = -0.063997022932475375
    rotMatrix25.Yx = 0.1409051766258875
    rotMatrix25.Yy = -0.012078705517908243
    rotMatrix25.Yz = 0.98994941086554555
    rotMatrix25.Zx = 0.84091339361741924
    rotMatrix25.Zy = -0.52627000622503273
    rotMatrix25.Zz = -0.12611322287032795
    translation25 = NXOpen.Point3d(0.16198235662419691, -13.00106030643807, -6.2133503397808099)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 2.977324695121951)
    
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects9 = [NXOpen.DisplayableObject.Null] * 2 
    objects9[0] = sketch16
    objects9[1] = arc3
    theSession.DisplayManager.BlankObjects(objects9)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal22 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin50, normal22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane22
    
    expression105 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression106 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId233, "Create Sketch Dialog")
    
    scalar11 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge19 = extrude4.FindObject("EDGE * 160 EXTRUDE(2) 140 {(65,-56,0)(60,-56,0)(55,-56,0) EXTRUDE(2)}")
    point82 = workPart.Points.CreatePoint(edge19, scalar11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction20 = workPart.Directions.CreateDirection(edge19, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face7 = extrude4.FindObject("FACE 160 {(60,-56,-5) EXTRUDE(2)}")
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face7, direction20, point82, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem8
    
    origin51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal23 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin51, normal23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom23 = [NXOpen.NXObject.Null] * 1 
    geom23[0] = face7
    plane23.SetGeometry(geom23)
    
    plane23.SetFlip(False)
    
    plane23.SetExpression(None)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    origin52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal24 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin52, normal24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression107 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane24.SynchronizeToPlane(plane23)
    
    scalar12 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point83 = workPart.Points.CreatePoint(edge19, scalar12, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane24.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom24 = [NXOpen.NXObject.Null] * 1 
    geom24[0] = face7
    plane24.SetGeometry(geom24)
    
    plane24.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane24.Evaluate()
    
    # ----------------------------------------------
    #   Menu: OK
    # ----------------------------------------------
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId234, None)
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject40 = sketchInPlaceBuilder8.Commit()
    
    sketch17 = nXObject40
    feature15 = sketch17.Feature
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs14 = theSession.UpdateManager.DoUpdate(markId236)
    
    sketch17.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId235, None)
    
    theSession.SetUndoMarkName(markId233, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression106)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point83)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression105)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane22.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression108)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression107)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane24.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId238, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint39 = NXOpen.Point3d(57.224213333333374, -56.0, 0.0)
    endPoint39 = NXOpen.Point3d(62.645047466666711, -56.0, 0.0)
    line35 = workPart.Curves.CreateLine(startPoint39, endPoint39)
    
    startPoint40 = NXOpen.Point3d(62.645047466666711, -56.0, 0.0)
    endPoint40 = NXOpen.Point3d(62.645047466666711, -56.0, -10.0)
    line36 = workPart.Curves.CreateLine(startPoint40, endPoint40)
    
    startPoint41 = NXOpen.Point3d(62.645047466666711, -56.0, -10.0)
    endPoint41 = NXOpen.Point3d(57.224213333333374, -56.0, -10.0)
    line37 = workPart.Curves.CreateLine(startPoint41, endPoint41)
    
    startPoint42 = NXOpen.Point3d(57.224213333333374, -56.0, -10.0)
    endPoint42 = NXOpen.Point3d(57.224213333333374, -56.0, 0.0)
    line38 = workPart.Curves.CreateLine(startPoint42, endPoint42)
    
    theSession.ActiveSketch.AddGeometry(line35, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line36, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line37, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line38, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_32.Geometry = line35
    geom1_32.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_32.SplineDefiningPointIndex = 0
    geom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_32.Geometry = line36
    geom2_32.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint68 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_32, geom2_32)
    
    geom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_33.Geometry = line36
    geom1_33.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_33.SplineDefiningPointIndex = 0
    geom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_33.Geometry = line37
    geom2_33.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint69 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_33, geom2_33)
    
    geom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_34.Geometry = line37
    geom1_34.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_34.SplineDefiningPointIndex = 0
    geom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_34.Geometry = line38
    geom2_34.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint70 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_34, geom2_34)
    
    geom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_35.Geometry = line38
    geom1_35.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_35.SplineDefiningPointIndex = 0
    geom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_35.Geometry = line35
    geom2_35.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint71 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_35, geom2_35)
    
    geom25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom25.Geometry = line35
    geom25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint72 = theSession.ActiveSketch.CreateHorizontalConstraint(geom25)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = line35
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line36
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint73 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_34, conGeom2_34)
    
    conGeom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_35.Geometry = line36
    conGeom1_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_35.SplineDefiningPointIndex = 0
    conGeom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_35.Geometry = line37
    conGeom2_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint74 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_35, conGeom2_35)
    
    conGeom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_36.Geometry = line37
    conGeom1_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_36.SplineDefiningPointIndex = 0
    conGeom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_36.Geometry = line38
    conGeom2_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint75 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_36, conGeom2_36)
    
    conGeom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_37.Geometry = line38
    conGeom1_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_37.SplineDefiningPointIndex = 0
    conGeom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_37.Geometry = line35
    conGeom2_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint76 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_37, conGeom2_37)
    
    conGeom1_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_38.Geometry = line35
    conGeom1_38.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_38.SplineDefiningPointIndex = 0
    conGeom2_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_38.Geometry = edge5
    conGeom2_38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_38.SplineDefiningPointIndex = 0
    help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help6.Point.X = 57.224213333333374
    help6.Point.Y = -56.0
    help6.Point.Z = 0.0
    help6.Parameter = 0.0
    sketchHelpedGeometricConstraint6 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_38, conGeom2_38, help6)
    
    conGeom1_39 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_39.Geometry = line37
    conGeom1_39.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_39.SplineDefiningPointIndex = 0
    conGeom2_39 = NXOpen.Sketch.ConstraintGeometry()
    
    edge20 = extrude4.FindObject("EDGE * 130 * 160 {(65,-56,-10)(60,-56,-10)(55,-56,-10) EXTRUDE(2)}")
    conGeom2_39.Geometry = edge20
    conGeom2_39.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_39.SplineDefiningPointIndex = 0
    help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help7.Point.X = 62.645047466666711
    help7.Point.Y = -56.0
    help7.Point.Z = -10.0
    help7.Parameter = 0.0
    sketchHelpedGeometricConstraint7 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_39, conGeom2_39, help7)
    
    dimObject1_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_18.Geometry = line36
    dimObject1_18.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_18.AssocValue = 0
    dimObject1_18.HelpPoint.X = 0.0
    dimObject1_18.HelpPoint.Y = 0.0
    dimObject1_18.HelpPoint.Z = 0.0
    dimObject1_18.View = NXOpen.NXObject.Null
    dimObject2_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_15.Geometry = line36
    dimObject2_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_15.AssocValue = 0
    dimObject2_15.HelpPoint.X = 0.0
    dimObject2_15.HelpPoint.Y = 0.0
    dimObject2_15.HelpPoint.Z = 0.0
    dimObject2_15.View = NXOpen.NXObject.Null
    dimOrigin18 = NXOpen.Point3d(59.622199466666707, -56.0, -5.0)
    sketchDimensionalConstraint18 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_18, dimObject2_15, dimOrigin18, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint16 = sketchDimensionalConstraint18
    dimension18 = sketchHelpedDimensionalConstraint16.AssociatedDimension
    
    expression109 = sketchHelpedDimensionalConstraint16.AssociatedExpression
    
    dimObject1_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_19.Geometry = line35
    dimObject1_19.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_19.AssocValue = 0
    dimObject1_19.HelpPoint.X = 0.0
    dimObject1_19.HelpPoint.Y = 0.0
    dimObject1_19.HelpPoint.Z = 0.0
    dimObject1_19.View = NXOpen.NXObject.Null
    dimObject2_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_16.Geometry = line35
    dimObject2_16.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_16.AssocValue = 0
    dimObject2_16.HelpPoint.X = 0.0
    dimObject2_16.HelpPoint.Y = 0.0
    dimObject2_16.HelpPoint.Z = 0.0
    dimObject2_16.View = NXOpen.NXObject.Null
    dimOrigin19 = NXOpen.Point3d(59.934630400000046, -56.0, -3.0228480000000002)
    sketchDimensionalConstraint19 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_19, dimObject2_16, dimOrigin19, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint17 = sketchDimensionalConstraint19
    dimension19 = sketchHelpedDimensionalConstraint17.AssociatedDimension
    
    expression110 = sketchHelpedDimensionalConstraint17.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms24 = [NXOpen.SmartObject.Null] * 4 
    geoms24[0] = line35
    geoms24[1] = line36
    geoms24[2] = line37
    geoms24[3] = line38
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms24)
    
    geoms25 = [NXOpen.SmartObject.Null] * 4 
    geoms25[0] = line35
    geoms25[1] = line36
    geoms25[2] = line37
    geoms25[3] = line38
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms25)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder32 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines169 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines169)
    
    lines170 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines170)
    
    lines171 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines171)
    
    lines172 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines172)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder32.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines173 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines173)
    
    lines174 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines174)
    
    lines175 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines175)
    
    lines176 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines176)
    
    theSession.SetUndoMarkName(markId239, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder32.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits975 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits976 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits977 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits978 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits979 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits980 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits981 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits982 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits983 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits984 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder32.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits985 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits986 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits987 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits988 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits989 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits990 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits991 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits992 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits993 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits994 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    point1_155 = NXOpen.Point3d(57.224213333333374, -56.0, -5.0)
    point2_155 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line38, workPart.ModelingViews.WorkView, point1_155, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_155)
    
    edge21 = extrude4.FindObject("EDGE * 160 * 170 {(55,-56,-10)(55,-56,-5)(55,-56,0) EXTRUDE(2)}")
    point1_156 = NXOpen.Point3d(54.999999999999986, -55.999999999999993, -5.0)
    point2_156 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge21, workPart.ModelingViews.WorkView, point1_156, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_156)
    
    point1_157 = NXOpen.Point3d(57.224213333333374, -56.0, -5.0)
    point2_157 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line38, workPart.ModelingViews.WorkView, point1_157, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_157)
    
    point1_158 = NXOpen.Point3d(54.999999999999986, -55.999999999999993, -5.0)
    point2_158 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge21, workPart.ModelingViews.WorkView, point1_158, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_158)
    
    dimensionlinearunits995 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits996 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits997 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits998 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits999 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1000 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin21 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin21.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin21.View = NXOpen.View.Null
    assocOrigin21.ViewOfGeometry = workPart.ModelingViews.WorkView
    point84 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin21.PointOnGeometry = point84
    assocOrigin21.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.DimensionLine = 0
    assocOrigin21.AssociatedView = NXOpen.View.Null
    assocOrigin21.AssociatedPoint = NXOpen.Point.Null
    assocOrigin21.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.XOffsetFactor = 0.0
    assocOrigin21.YOffsetFactor = 0.0
    assocOrigin21.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder32.Origin.SetAssociativeOrigin(assocOrigin21)
    
    point85 = NXOpen.Point3d(56.335552000000042, -56.0, -6.6649599999999589)
    sketchRapidDimensionBuilder32.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point85)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.TextCentered = True
    
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject41 = sketchRapidDimensionBuilder32.Commit()
    
    theSession.DeleteUndoMark(markId240, None)
    
    theSession.SetUndoMarkName(markId239, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId239, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder32.Destroy()
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder33 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines177 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBefore(lines177)
    
    lines178 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAfter(lines178)
    
    lines179 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAbove(lines179)
    
    lines180 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBelow(lines180)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder33.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId241, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder33.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1001 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1002 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1003 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1004 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1005 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1006 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1007 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1008 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1009 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1010 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder33.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1011 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1012 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1013 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1014 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1015 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1016 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1017 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1018 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1019 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1020 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    expression111 = workPart.Expressions.FindObject("p41")
    expression111.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId241, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId242, None)
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId241, "Edit Driving Value")
    
    point1_159 = NXOpen.Point3d(62.420834133333322, -56.0, -4.9999999999999991)
    point2_159 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line36, workPart.ModelingViews.WorkView, point1_159, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_159)
    
    point1_160 = NXOpen.Point3d(65.0, -56.0, -5.0)
    point2_160 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge18, workPart.ModelingViews.WorkView, point1_160, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_160)
    
    point1_161 = NXOpen.Point3d(62.420834133333322, -56.0, -4.9999999999999991)
    point2_161 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line36, workPart.ModelingViews.WorkView, point1_161, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_161)
    
    point1_162 = NXOpen.Point3d(65.0, -56.0, -5.0)
    point2_162 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge18, workPart.ModelingViews.WorkView, point1_162, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_162)
    
    dimensionlinearunits1021 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1022 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1023 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1024 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1025 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1026 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin22 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin22.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin22.View = NXOpen.View.Null
    assocOrigin22.ViewOfGeometry = workPart.ModelingViews.WorkView
    point86 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin22.PointOnGeometry = point86
    assocOrigin22.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.DimensionLine = 0
    assocOrigin22.AssociatedView = NXOpen.View.Null
    assocOrigin22.AssociatedPoint = NXOpen.Point.Null
    assocOrigin22.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.XOffsetFactor = 0.0
    assocOrigin22.YOffsetFactor = 0.0
    assocOrigin22.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder33.Origin.SetAssociativeOrigin(assocOrigin22)
    
    point87 = NXOpen.Point3d(63.889173333333382, -56.0, -7.0204245333332969)
    sketchRapidDimensionBuilder33.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point87)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.TextCentered = True
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject42 = sketchRapidDimensionBuilder33.Commit()
    
    theSession.DeleteUndoMark(markId244, None)
    
    theSession.SetUndoMarkName(markId243, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId243, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder33.Destroy()
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder34 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines181 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBefore(lines181)
    
    lines182 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAfter(lines182)
    
    lines183 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAbove(lines183)
    
    lines184 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBelow(lines184)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder34.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId245, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder34.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1027 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1028 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1029 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1030 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1031 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1032 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1033 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1034 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1035 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1036 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder34.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1037 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1038 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1039 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1040 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1041 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1042 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1043 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1044 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1045 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1046 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    expression112 = workPart.Expressions.FindObject("p42")
    expression112.SetFormula("2")
    
    theSession.SetUndoMarkVisibility(markId245, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId246, None)
    
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId245, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder34.Destroy()
    
    theSession.UndoToMark(markId247, None)
    
    theSession.DeleteUndoMark(markId247, None)
    
    sketchRapidDimensionBuilder34.Destroy()
    
    sketch18 = theSession.ActiveSketch
    
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression113 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies83 = [NXOpen.Body.Null] * 1 
    targetBodies83[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies83)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("29")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies84 = [NXOpen.Body.Null] * 1 
    targetBodies84[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies84)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId249, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features9 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature8 = feature15
    features9[0] = sketchFeature8
    curveFeatureRule9 = workPart.ScRuleFactory.CreateRuleCurveFeature(features9)
    
    section9.AllowSelfIntersection(True)
    
    rules9 = [None] * 1 
    rules9[0] = curveFeatureRule9
    helpPoint9 = NXOpen.Point3d(63.000000000000099, -56.000000000000128, -5.8522723538032162)
    section9.AddToSection(rules9, line36, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint9, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId251, None)
    
    direction21 = workPart.Directions.CreateDirection(sketch18, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction21
    
    targetBodies85 = [NXOpen.Body.Null] * 1 
    targetBodies85[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies85)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies86 = [NXOpen.Body.Null] * 1 
    targetBodies86[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies86)
    
    expression114 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId250, None)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies87 = [NXOpen.Body.Null] * 1 
    targetBodies87[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies87)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies88 = [NXOpen.Body.Null] * 1 
    targetBodies88[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies88)
    
    direction22 = extrudeBuilder9.Direction
    
    success5 = direction22.ReverseDirection()
    
    extrudeBuilder9.Direction = direction22
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies89 = [NXOpen.Body.Null] * 1 
    targetBodies89[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies89)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies90 = [NXOpen.Body.Null] * 1 
    targetBodies90[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies90)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies91 = [NXOpen.Body.Null] * 1 
    targetBodies91[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies91)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies92 = [NXOpen.Body.Null] * 1 
    targetBodies92[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies92)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies93 = [NXOpen.Body.Null] * 1 
    targetBodies93[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies93)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies94 = [NXOpen.Body.Null] * 1 
    targetBodies94[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies94)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies95 = [NXOpen.Body.Null] * 1 
    targetBodies95[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies95)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("29")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies96 = [NXOpen.Body.Null] * 1 
    targetBodies96[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies96)
    
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId252, None)
    
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    feature16 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId253, None)
    
    theSession.SetUndoMarkName(markId249, "Extrude")
    
    expression115 = extrudeBuilder9.Limits.StartExtend.Value
    expression116 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression113)
    
    workPart.Expressions.Delete(expression114)
    
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects10 = [NXOpen.DisplayableObject.Null] * 5 
    objects10[0] = line35
    objects10[1] = line36
    objects10[2] = line37
    objects10[3] = line38
    objects10[4] = sketch18
    theSession.DisplayManager.BlankObjects(objects10)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = 0.49292163674847939
    rotMatrix26.Xy = 0.86832721716836225
    rotMatrix26.Xz = -0.055100852532886338
    rotMatrix26.Yx = -0.20051539185674627
    rotMatrix26.Yy = 0.17499395696704714
    rotMatrix26.Yz = 0.96393500437195068
    rotMatrix26.Zx = 0.84665331609445549
    rotMatrix26.Zy = -0.46409585103690143
    rotMatrix26.Zz = 0.26037127989968206
    translation26 = NXOpen.Point3d(1.9369221776940115, 7.4841738025199565, -6.5577456884029885)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 2.977324695121951)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()